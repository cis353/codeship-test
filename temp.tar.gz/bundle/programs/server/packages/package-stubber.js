(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;

/* Package-scope variables */
var PackageStubber;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/package-stubber/miniset.js                                                                    //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
(function (context) {                                                                                     // 1
"use strict";                                                                                             // 2
                                                                                                          // 3
//-------------------------------------------                                                             // 4
// Simple implementation of a Set in javascript                                                           // 5
//                                                                                                        // 6
// Source: https://github.com/jfriend00/Javascript-Set/blob/master/miniset.js                             // 7
//                                                                                                        // 8
// Supports any element type that can uniquely be identified                                              // 9
//    with its string conversion (e.g. toString() operator).                                              // 10
// This includes strings, numbers, dates, etc...                                                          // 11
// It does not include objects or arrays though                                                           // 12
//    one could implement a toString() operator                                                           // 13
//    on an object that would uniquely identify                                                           // 14
//    the object.                                                                                         // 15
//                                                                                                        // 16
// Uses a javascript object to hold the Set                                                               // 17
//                                                                                                        // 18
// This is a subset of the Set object designed to be smaller and faster, but                              // 19
// not as extensible.  This implementation should not be mixed with the Set object                        // 20
// as in don't pass a miniSet to a Set constructor or vice versa.  Both can exist and be                  // 21
// used separately in the same project, though if you want the features of the other                      // 22
// sets, then you should probably just include them and not include miniSet as it's                       // 23
// really designed for someone who just wants the smallest amount of code to get                          // 24
// a Set interface.                                                                                       // 25
//                                                                                                        // 26
// s.add(key)                      // adds a key to the Set (if it doesn't already exist)                 // 27
// s.add(key1, key2, key3)         // adds multiple keys                                                  // 28
// s.add([key1, key2, key3])       // adds multiple keys                                                  // 29
// s.add(otherSet)                 // adds another Set to this Set                                        // 30
// s.add(arrayLikeObject)          // adds anything that a subclass returns true on _isPseudoArray()      // 31
// s.remove(key)                   // removes a key from the Set                                          // 32
// s.remove(["a", "b"]);           // removes all keys in the passed in array                             // 33
// s.remove("a", "b", ["first", "second"]);   // removes all keys specified                               // 34
// s.has(key)                      // returns true/false if key exists in the Set                         // 35
// s.isEmpty()                     // returns true/false for whether Set is empty                         // 36
// s.keys()                        // returns an array of keys in the Set                                 // 37
// s.clear()                       // clears all data from the Set                                        // 38
// s.each(fn)                      // iterate over all items in the Set (return this for method chaining) // 39
//                                                                                                        // 40
// All methods return the object for use in chaining except when the point                                // 41
// of the method is to return a specific value (such as .keys() or .isEmpty())                            // 42
//-------------------------------------------                                                             // 43
                                                                                                          // 44
                                                                                                          // 45
// polyfill for Array.isArray                                                                             // 46
if(!Array.isArray) {                                                                                      // 47
    Array.isArray = function (vArg) {                                                                     // 48
        return Object.prototype.toString.call(vArg) === "[object Array]";                                 // 49
    };                                                                                                    // 50
}                                                                                                         // 51
                                                                                                          // 52
function MiniSet(initialData) {                                                                           // 53
    // Usage:                                                                                             // 54
    // new MiniSet()                                                                                      // 55
    // new MiniSet(1,2,3,4,5)                                                                             // 56
    // new MiniSet(["1", "2", "3", "4", "5"])                                                             // 57
    // new MiniSet(otherSet)                                                                              // 58
    // new MiniSet(otherSet1, otherSet2, ...)                                                             // 59
    this.data = {};                                                                                       // 60
    this.add.apply(this, arguments);                                                                      // 61
}                                                                                                         // 62
                                                                                                          // 63
MiniSet.prototype = {                                                                                     // 64
    // usage:                                                                                             // 65
    // add(key)                                                                                           // 66
    // add([key1, key2, key3])                                                                            // 67
    // add(otherSet)                                                                                      // 68
    // add(key1, [key2, key3, key4], otherSet)                                                            // 69
    // add supports the EXACT same arguments as the constructor                                           // 70
    add: function() {                                                                                     // 71
        var key;                                                                                          // 72
        for (var i = 0; i < arguments.length; i++) {                                                      // 73
            key = arguments[i];                                                                           // 74
            if (Array.isArray(key)) {                                                                     // 75
                for (var j = 0; j < key.length; j++) {                                                    // 76
                    this.data[key[j]] = key[j];                                                           // 77
                }                                                                                         // 78
            } else if (key instanceof MiniSet) {                                                          // 79
                var self = this;                                                                          // 80
                key.each(function(val, key) {                                                             // 81
                    self.data[key] = val;                                                                 // 82
                });                                                                                       // 83
            } else {                                                                                      // 84
                // just a key, so add it                                                                  // 85
                this.data[key] = key;                                                                     // 86
            }                                                                                             // 87
        }                                                                                                 // 88
        return this;                                                                                      // 89
    },                                                                                                    // 90
    // private: to remove a single item                                                                   // 91
    // does not have all the argument flexibility that remove does                                        // 92
    _removeItem: function(key) {                                                                          // 93
        delete this.data[key];                                                                            // 94
    },                                                                                                    // 95
    // usage:                                                                                             // 96
    // remove(key)                                                                                        // 97
    // remove(key1, key2, key3)                                                                           // 98
    // remove([key1, key2, key3])                                                                         // 99
    remove: function(key) {                                                                               // 100
        // can be one or more args                                                                        // 101
        // each arg can be a string key or an array of string keys                                        // 102
        var item;                                                                                         // 103
        for (var j = 0; j < arguments.length; j++) {                                                      // 104
            item = arguments[j];                                                                          // 105
            if (Array.isArray(item)) {                                                                    // 106
                // must be an array of keys                                                               // 107
                for (var i = 0; i < item.length; i++) {                                                   // 108
                    this._removeItem(item[i]);                                                            // 109
                }                                                                                         // 110
            } else {                                                                                      // 111
                this._removeItem(item);                                                                   // 112
            }                                                                                             // 113
        }                                                                                                 // 114
        return this;                                                                                      // 115
    },                                                                                                    // 116
    // returns true/false on whether the key exists                                                       // 117
    has: function(key) {                                                                                  // 118
        return Object.prototype.hasOwnProperty.call(this.data, key);                                      // 119
    },                                                                                                    // 120
    // tells you if the Set is empty or not                                                               // 121
    isEmpty: function() {                                                                                 // 122
        for (var key in this.data) {                                                                      // 123
            if (this.has(key)) {                                                                          // 124
                return false;                                                                             // 125
            }                                                                                             // 126
        }                                                                                                 // 127
        return true;                                                                                      // 128
    },                                                                                                    // 129
    // returns an array of all keys in the Set                                                            // 130
    // returns the original key (not the string converted form)                                           // 131
    keys: function() {                                                                                    // 132
        var results = [];                                                                                 // 133
        this.each(function(data) {                                                                        // 134
            results.push(data);                                                                           // 135
        });                                                                                               // 136
        return results;                                                                                   // 137
    },                                                                                                    // 138
    // clears the Set                                                                                     // 139
    clear: function() {                                                                                   // 140
        this.data = {};                                                                                   // 141
        return this;                                                                                      // 142
    },                                                                                                    // 143
    // iterate over all elements in the Set until callback returns false                                  // 144
    // myCallback(key) is the callback form                                                               // 145
    // If the callback returns false, then the iteration is stopped                                       // 146
    // returns the Set to allow method chaining                                                           // 147
    each: function(fn) {                                                                                  // 148
        this.eachReturn(fn);                                                                              // 149
        return this;                                                                                      // 150
    },                                                                                                    // 151
    // iterate all elements until callback returns false                                                  // 152
    // myCallback(key) is the callback form                                                               // 153
    // returns false if iteration was stopped                                                             // 154
    // returns true if iteration completed                                                                // 155
    eachReturn: function(fn) {                                                                            // 156
        for (var key in this.data) {                                                                      // 157
            if (this.has(key)) {                                                                          // 158
                if (fn.call(this, this.data[key], key) === false) {                                       // 159
                    return false;                                                                         // 160
                }                                                                                         // 161
            }                                                                                             // 162
        }                                                                                                 // 163
        return true;                                                                                      // 164
    }                                                                                                     // 165
};                                                                                                        // 166
                                                                                                          // 167
MiniSet.prototype.constructor = MiniSet;                                                                  // 168
                                                                                                          // 169
context.MiniSet = MiniSet;                                                                                // 170
                                                                                                          // 171
})('undefined' === typeof global ? window : global);                                                      // 172
                                                                                                          // 173
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/package-stubber/main.js                                                                       //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
;(function () {                                                                                           // 1
                                                                                                          // 2
if ('undefined' === typeof PackageStubber) {                                                              // 3
  PackageStubber = {}                                                                                     // 4
}                                                                                                         // 5
                                                                                                          // 6
"use strict";                                                                                             // 7
                                                                                                          // 8
var pwd = process.env.PWD,                                                                                // 9
    DEBUG = process.env.DEBUG,                                                                            // 10
    fs = Npm.require('fs'),                                                                               // 11
    path = Npm.require('path'),                                                                           // 12
    glob = Npm.require('glob'),                                                                           // 13
    defaultPackagesToIgnore = [                                                                           // 14
      'meteor-package-stubber',                                                                           // 15
      'package-stubber',                                                                                  // 16
      'velocity',                                                                                         // 17
      'velocity-html-reporter',                                                                           // 18
      'mirror'                                                                                            // 19
    ]                                                                                                     // 20
                                                                                                          // 21
_.extend(PackageStubber, {                                                                                // 22
                                                                                                          // 23
  /**                                                                                                     // 24
   * The string used to replace functions found on stubbed objects.                                       // 25
   *                                                                                                      // 26
   * @property {String} functionReplacementStr                                                            // 27
   */                                                                                                     // 28
  functionReplacementStr: "function emptyFn () {}",                                                       // 29
                                                                                                          // 30
                                                                                                          // 31
  /**                                                                                                     // 32
   * Holds validation functions for class functions.                                                      // 33
   *                                                                                                      // 34
   * @property {Object} validate                                                                          // 35
   */                                                                                                     // 36
  validate: {                                                                                             // 37
                                                                                                          // 38
    /**                                                                                                   // 39
     * Validate function arguments                                                                        // 40
     *                                                                                                    // 41
     * @method validate.stubPackages                                                                      // 42
     */                                                                                                   // 43
    stubPackages: function (options) {                                                                    // 44
      var dontStubType,                                                                                   // 45
          dontStubTypeErrorMsg                                                                            // 46
                                                                                                          // 47
      if ('string' != typeof options.outfile) {                                                           // 48
        throw new Error("[PackageStubber.stubPackages] If supplied, the " +                               // 49
                        "'outfile' field must be the path to a file to write " +                          // 50
                        "stub output to.  It can be an absolute path or " +                               // 51
                        "relative to the current Meteor application")                                     // 52
      }                                                                                                   // 53
                                                                                                          // 54
      dontStubType = _.isArray(options.dontStub) ? 'array'                                                // 55
                                                 : typeof options.dontStub                                // 56
      dontStubTypeErrorMsg = "[PackageStubber.stubPackages] If supplied, the " +                          // 57
                              "'dontStub' field must be the name of a " +                                 // 58
                              "package or an array of package names"                                      // 59
                                                                                                          // 60
      if (dontStubType !== 'string' && dontStubType !== 'array') {                                        // 61
        throw new Error(dontStubTypeErrorMsg)                                                             // 62
      }                                                                                                   // 63
                                                                                                          // 64
      function isNotString (something) {                                                                  // 65
        return 'string' !== typeof something                                                              // 66
      }                                                                                                   // 67
                                                                                                          // 68
      // test each element to make sure its a string                                                      // 69
      if (dontStubType === 'array' &&                                                                     // 70
          _.some(options.dontStub, isNotString)) {                                                        // 71
        throw new Error(dontStubTypeErrorMsg)                                                             // 72
      }                                                                                                   // 73
    },                                                                                                    // 74
                                                                                                          // 75
    /**                                                                                                   // 76
     * Validate function arguments                                                                        // 77
     *                                                                                                    // 78
     * @method validate.deepCopyReplaceFn                                                                 // 79
     */                                                                                                   // 80
    deepCopyReplaceFn: function (target, fnPlaceholder) {                                                 // 81
      var lbl = "[PackageStubber.deepCopyReplaceFn] "                                                     // 82
                                                                                                          // 83
      if (null === target ||                                                                              // 84
          'object' !== typeof target) {                                                                   // 85
        throw new Error(lbl + "Required field `target` must be a non-null " +                             // 86
                        "object. Actual type: '" + typeof target + "'")                                   // 87
      }                                                                                                   // 88
      if (null !== fnPlaceholder &&                                                                       // 89
          'undefined' !== typeof fnPlaceholder &&                                                         // 90
          'string' !== typeof fnPlaceholder) {                                                            // 91
        throw new Error(lbl + "If supplied, the 'fnPlaceholder' field must " +                            // 92
                        "be a string")                                                                    // 93
      }                                                                                                   // 94
    }                                                                                                     // 95
                                                                                                          // 96
  },  // end validate                                                                                     // 97
                                                                                                          // 98
                                                                                                          // 99
  /**                                                                                                     // 100
   * Create stubs for all smart packages in the current Meteor app.                                       // 101
   * Stubs will be written to a javascript file.                                                          // 102
   *                                                                                                      // 103
   * NOTE: This function must be run in a Meteor app's context so that the                                // 104
   * smart packages to stub are loaded and their object graphs can be traversed.                          // 105
   *                                                                                                      // 106
   * @method stubPackages                                                                                 // 107
   * @param {Object} options                                                                              // 108
   * @param {Array|String} [options.dontStub] Names of packages to ignore                                 // 109
   *                           (ie. not stub).  Default: []                                               // 110
   * @param {String} [options.outfile] The file path to write the stubs to.                               // 111
   *                           Can be either an absolute file path or relative                            // 112
   *                           to the current Meteor application.                                         // 113
   *                           Default: `tests/a1-package-stubs.js`                                       // 114
   */                                                                                                     // 115
  stubPackages: function (options) {                                                                      // 116
    var packagesToIgnore,                                                                                 // 117
        coreStubs,                                                                                        // 118
        communityStubs,                                                                                   // 119
        generatedStubs,                                                                                   // 120
        preMadeStubs                                                                                      // 121
                                                                                                          // 122
    options = options || {}                                                                               // 123
                                                                                                          // 124
    options.outfile = options.outfile ||                                                                  // 125
                      path.join(pwd, 'tests', 'a1-package-stubs.js')                                      // 126
    options.dontStub = options.dontStub || []                                                             // 127
                                                                                                          // 128
    PackageStubber.validate.stubPackages(options)                                                         // 129
                                                                                                          // 130
    if (options.outfile[0] !== path.sep) {                                                                // 131
      options.outfile = path.join(pwd, options.outfile)                                                   // 132
    }                                                                                                     // 133
                                                                                                          // 134
    options.packagesToIgnore = PackageStubber.listPackagesToIgnore(options)                               // 135
                                                                                                          // 136
    coreStubs = PackageStubber.getCoreStubs(options)                                                      // 137
    communityStubs = PackageStubber.getCommunityStubs(options)                                            // 138
    preMadeStubs = coreStubs.concat(communityStubs)                                                       // 139
                                                                                                          // 140
    DEBUG && console.log("[PackageStubber] won't auto-stub these packages:",                              // 141
                         options.packagesToIgnore.keys())                                                 // 142
                                                                                                          // 143
    generatedStubs = PackageStubber.buildStubs(options)                                                   // 144
                                                                                                          // 145
    PackageStubber.writeStubs(options.outfile, generatedStubs, preMadeStubs)                              // 146
  },  // end stubPackages                                                                                 // 147
                                                                                                          // 148
                                                                                                          // 149
                                                                                                          // 150
                                                                                                          // 151
  /**                                                                                                     // 152
   * List all pre-made stubs for core packages.                                                           // 153
   *                                                                                                      // 154
   * Since they are core and we have no way to detect their use (even                                     // 155
   * .meteor/packages doesn't have a complete list since dependencies                                     // 156
   * don't show up there), these are always included unless specifically                                  // 157
   * excluded in 'dontStub'                                                                               // 158
   *                                                                                                      // 159
   * If a custom stub is found, the name of that package will be added to                                 // 160
   * the packagesToIgnore set so the package auto-stubber does not try to stub                            // 161
   * it.                                                                                                  // 162
   *                                                                                                      // 163
   * @method getCoreStubs                                                                                 // 164
   * @param {Object} [options]                                                                            // 165
   * @param {String} [options.appDir] Directory path of Meteor application to                             // 166
   *                                  identify test packages for.                                         // 167
   *                                  Default: PWD (process working directory)                            // 168
   * @param {MiniSet} [options.packagesToIgnore] Set of package names that                                // 169
   *                  should not be stubbed.  May be added to in function.                                // 170
   * @return {Array} list of core stub data objs                                                          // 171
   *                  { package: name, filePath: pathToStub }                                             // 172
   */                                                                                                     // 173
  getCoreStubs: function (options) {                                                                      // 174
    var coreStubs = [],                                                                                   // 175
        searchPath,                                                                                       // 176
        packagesToIgnore,                                                                                 // 177
        stubFiles                                                                                         // 178
                                                                                                          // 179
    options = options || {}                                                                               // 180
    options.appDir = normalizeAppDir(options)                                                             // 181
                                                                                                          // 182
    searchPath = '/packages/package-stubber/core-stubs/*.js'                                              // 183
    stubFiles = glob.sync(_p(options.appDir + searchPath))                                                // 184
                                                                                                          // 185
    packagesToIgnore = options.packagesToIgnore || new MiniSet()                                          // 186
                                                                                                          // 187
    _.each(stubFiles, function (filePath) {                                                               // 188
      var corePackage = path.basename(filePath, '.js')                                                    // 189
                                                                                                          // 190
      if (!packagesToIgnore.has(corePackage)) {                                                           // 191
        DEBUG &&                                                                                          // 192
          console.log('[PackageStubber] custom stub found for core package',                              // 193
                       corePackage)                                                                       // 194
        packagesToIgnore.add(corePackage)                                                                 // 195
        coreStubs.push({                                                                                  // 196
          package: corePackage,                                                                           // 197
          filePath: filePath                                                                              // 198
        })                                                                                                // 199
      }                                                                                                   // 200
    })                                                                                                    // 201
                                                                                                          // 202
    return coreStubs                                                                                      // 203
  },  // end getCoreStubs                                                                                 // 204
                                                                                                          // 205
                                                                                                          // 206
  /**                                                                                                     // 207
   * List all pre-made stubs for community packages.                                                      // 208
   *                                                                                                      // 209
   * If a community stub is found, the name of that package will be added to                              // 210
   * the packagesToIgnore set so the package auto-stubber does not try to stub                            // 211
   * it.                                                                                                  // 212
   *                                                                                                      // 213
   * @method getCoreStubs                                                                                 // 214
   * @param {Object} [options]                                                                            // 215
   * @param {MiniSet} [options.packagesToIgnore] Set of package names that                                // 216
   *                  should not be stubbed.  May be added to in function.                                // 217
   * @return {Array} list of community stub data objs                                                     // 218
   *                  { package: name, filePath: pathToStub }                                             // 219
   */                                                                                                     // 220
  getCommunityStubs: function (options) {                                                                 // 221
    var usedPackages = PackageStubber.listPackages(options),                                              // 222
        packagesToIgnore,                                                                                 // 223
        communityStubs = [],                                                                              // 224
        appDir                                                                                            // 225
                                                                                                          // 226
    options = options || {}                                                                               // 227
    options.appDir = normalizeAppDir(options)                                                             // 228
    packagesToIgnore = options.packagesToIgnore || new MiniSet()                                          // 229
                                                                                                          // 230
    appDir = options.appDir                                                                               // 231
                                                                                                          // 232
    // check for pre-made stubs for used community packages                                               // 233
    _.each(usedPackages, function (packageName) {                                                         // 234
      var stubFile = packageName + ".js",                                                                 // 235
          stubFilePath,                                                                                   // 236
          searchPath                                                                                      // 237
                                                                                                          // 238
      searchPath = '/packages/package-stubber/community-stubs/' + stubFile                                // 239
      stubFilePath = _p(appDir + searchPath)                                                              // 240
                                                                                                          // 241
      if (!packagesToIgnore.has(packageName) && fs.existsSync(stubFilePath)) {                            // 242
        DEBUG && console.log('[PackageStubber] community stub found for',                                 // 243
                             packageName)                                                                 // 244
        packagesToIgnore.add(packageName)                                                                 // 245
        communityStubs.push({                                                                             // 246
          package: packageName,                                                                           // 247
          filePath: stubFilePath                                                                          // 248
        })                                                                                                // 249
      }                                                                                                   // 250
    })                                                                                                    // 251
                                                                                                          // 252
    return communityStubs                                                                                 // 253
  },  // getCommunityStubs                                                                                // 254
                                                                                                          // 255
                                                                                                          // 256
  /**                                                                                                     // 257
   * List the names of all non-core packages used by the app.                                             // 258
   *                                                                                                      // 259
   * @method listPackages                                                                                 // 260
   * @param {Object} [options]                                                                            // 261
   * @param {String} [options.appDir] Directory path of Meteor application to                             // 262
   *                                  identify package exports for.                                       // 263
   *                                  Default: PWD (process working directory)                            // 264
   * @return {Array} names of all non-core packages used by app                                           // 265
   */                                                                                                     // 266
  listPackages: function (options) {                                                                      // 267
    options = options || {}                                                                               // 268
                                                                                                          // 269
    options.appDir = normalizeAppDir(options)                                                             // 270
                                                                                                          // 271
    return ls (path.join(options.appDir, 'packages'))                                                     // 272
  },                                                                                                      // 273
                                                                                                          // 274
                                                                                                          // 275
  /**                                                                                                     // 276
   * Get the names of all objects/functions which are exported by packages                                // 277
   * in a Meteor application.                                                                             // 278
   * Exports are identified by parsing each package's `package.js` file and                               // 279
   * extracting out their `api.export(...)` calls.                                                        // 280
   *                                                                                                      // 281
   * Used by PackageStubber to identify which global objects to stub.                                     // 282
   *                                                                                                      // 283
   * NOTE: Does not need to be run in a Meteor context.                                                   // 284
   *                                                                                                      // 285
   * @method listPackageExports                                                                           // 286
   * @param {Object} [options]                                                                            // 287
   * @param {String} [options.appDir] Directory path of Meteor application to                             // 288
   *                                  identify package exports for.                                       // 289
   *                                  Default: PWD (process working directory)                            // 290
   * @param {MiniSet} [options.packagesToIgnore] Set of package names to ignore                           // 291
   * @return {Array} list of info objects about package exports                                           // 292
   *   ex. [{package: 'iron-router', name: 'RouteController'}, {...}]                                     // 293
   */                                                                                                     // 294
  listPackageExports: function (options) {                                                                // 295
    var packageJsFiles,                                                                                   // 296
        packageExports = []                                                                               // 297
                                                                                                          // 298
    options = options || {}                                                                               // 299
    options.appDir = normalizeAppDir(options)                                                             // 300
                                                                                                          // 301
    packageJsFiles = glob.sync(path.join("*", "package.js"),                                              // 302
                               {cwd: path.join(options.appDir, "packages")})                              // 303
                                                                                                          // 304
    _.each(packageJsFiles, function (filePath) {                                                          // 305
      var packageName = path.dirname(filePath),                                                           // 306
          exportsRE = /api\.export\s*\(\s*(?:(['"])(.+?)\1|(\[.+?\]))/igm,                                // 307
          file,                                                                                           // 308
          found                                                                                           // 309
                                                                                                          // 310
      if (options.packagesToIgnore && options.packagesToIgnore.has(packageName)) {                        // 311
        // skip this package.  don't need to auto-stub                                                    // 312
        return                                                                                            // 313
      }                                                                                                   // 314
                                                                                                          // 315
      try {                                                                                               // 316
        file = fs.readFileSync(path.join(options.appDir, "packages", filePath), 'utf8')                   // 317
        while(found = exportsRE.exec(file)) {                                                             // 318
          var exports = []                                                                                // 319
          if (found[2]) {                                                                                 // 320
            exports = [found[2]]                                                                          // 321
          } else if (found[3]) {                                                                          // 322
            exports = JSON.parse(found[3].replace(/'/g, '"'))                                             // 323
          }                                                                                               // 324
                                                                                                          // 325
          exports.forEach(function (name) {                                                               // 326
            DEBUG && console.log('[PackageStubber] found', name, 'in', filePath)                          // 327
            packageExports.push({                                                                         // 328
              package: packageName,                                                                       // 329
              name: name                                                                                  // 330
            })                                                                                            // 331
          });                                                                                             // 332
        }                                                                                                 // 333
      } catch (ex) {                                                                                      // 334
        DEBUG && console.log('[PackageStubber] Error reading file', filePath, ex)                         // 335
      }                                                                                                   // 336
    })                                                                                                    // 337
                                                                                                          // 338
    return packageExports                                                                                 // 339
  },  // end listPackageExports                                                                           // 340
                                                                                                          // 341
                                                                                                          // 342
  /**                                                                                                     // 343
   * Generate stubs in js source string form that can be written to a file                                // 344
   * and loaded later by a regular js code file loader (ex. jasmine-unit)                                 // 345
   *                                                                                                      // 346
   * @method buildStubs                                                                                   // 347
   * @param {Object} [options]                                                                            // 348
   * @param {String} [options.appDir] Directory path of Meteor application to                             // 349
   *                                  identify package exports for.                                       // 350
   *                                  Default: PWD (process working directory)                            // 351
   * @param {MiniSet} [options.packagesToIgnore] Set of package names that                                // 352
   *                  should not be stubbed.  May be added to in function.                                // 353
   * @return {Object} object with one field of type `string` for each global                              // 354
   *                  field that is being stubbed (ie. each package export)                               // 355
   */                                                                                                     // 356
  buildStubs: function (options) {                                                                        // 357
    var packageExports,                                                                                   // 358
        stubs = {}                                                                                        // 359
                                                                                                          // 360
    packageExports = PackageStubber.listPackageExports(options)                                           // 361
                                                                                                          // 362
    _.each(packageExports, function (exportInfo) {                                                        // 363
      var name = exportInfo.name,                                                                         // 364
          package = exportInfo.package,                                                                   // 365
          toStub = global[name]                                                                           // 366
                                                                                                          // 367
      if (toStub) {                                                                                       // 368
        DEBUG && console.log("[PackageStubber] stubbing", typeof toStub,                                  // 369
                             "'" + name + "' in package", package)                                        // 370
        // `stubs` object will have one field of type `string` for each global                            // 371
        // object that is being stubbed (ie. each package export)                                         // 372
        stubs[name] = PackageStubber.generateStubSource(toStub, name, package)                            // 373
      } else {                                                                                            // 374
        DEBUG && console.log('[PackageStubber] ignored missing export', name,                             // 375
                             'from package', package + ". NOTE: You may have" +                           // 376
                             " to stub this export yourself if you " +                                    // 377
                             "experience errors testing client-side code.")                               // 378
      }                                                                                                   // 379
    })                                                                                                    // 380
                                                                                                          // 381
    return stubs                                                                                          // 382
  },  // end buildStubs                                                                                   // 383
                                                                                                          // 384
                                                                                                          // 385
  /**                                                                                                     // 386
   * Write both generated stubs and pre-existing stubs to file                                            // 387
   *                                                                                                      // 388
   * @method writeStubs                                                                                   // 389
   * @param {Object} generatedStubs object with one field of type `string`                                // 390
   *                 for each global field that is being stubbed (ie. each                                // 391
   *                 package export)                                                                      // 392
   */                                                                                                     // 393
  writeStubs: function (outfile, generatedStubs, preMadeStubs) {                                          // 394
    var name,                                                                                             // 395
        str = ''                                                                                          // 396
                                                                                                          // 397
    // prep for file write                                                                                // 398
    for (name in generatedStubs) {                                                                        // 399
      str += "\n"                                                                                         // 400
      str += "////////////////////////////////////////////////////////////\n"                             // 401
      str += "// " + name + "\n"                                                                          // 402
      str += "//\n"                                                                                       // 403
      str += name + " = " + generatedStubs[name] + ";\n\n"                                                // 404
    }                                                                                                     // 405
                                                                                                          // 406
    fs.writeFileSync(outfile, str)                                                                        // 407
                                                                                                          // 408
    // append custom stubs                                                                                // 409
    _.each(preMadeStubs, function (stubConfig) {                                                          // 410
      DEBUG && console.log('[PackageStubber] appending pre-made stub for',                                // 411
                           stubConfig.package)                                                            // 412
      fs.appendFileSync(outfile, fs.readFileSync(stubConfig.filePath))                                    // 413
    })                                                                                                    // 414
  },  // end writeStubs                                                                                   // 415
                                                                                                          // 416
                                                                                                          // 417
  /**                                                                                                     // 418
   * Get all packages that should be ignored (ie. not stubbed)                                            // 419
   *                                                                                                      // 420
   * @method listPackagesToIgnore                                                                         // 421
   * @param {Object} [options]                                                                            // 422
   * @param {String} [options.appDir] Directory path of Meteor application to                             // 423
   *                                  identify test packages for.                                         // 424
   *                                  Default: PWD (process working directory)                            // 425
   * @param {Array|String} [options.dontStub] Names of packages to ignore                                 // 426
   *                           (ie. not stub).  Default: []                                               // 427
   * @return {MiniSet} set of all package names that should not be stubbed.                               // 428
   *                 Ex. ['jasmine-unit', 'mocha-web-velocity']                                           // 429
   */                                                                                                     // 430
  listPackagesToIgnore: function (options) {                                                              // 431
    var packagesToIgnore = new MiniSet(),                                                                 // 432
        dontStub                                                                                          // 433
                                                                                                          // 434
    // ignore test packages                                                                               // 435
    packagesToIgnore.add(PackageStubber.listTestPackages(options))                                        // 436
                                                                                                          // 437
    // ignore defaults                                                                                    // 438
    _.each(defaultPackagesToIgnore, function (packageName) {                                              // 439
      packagesToIgnore.add(packageName)                                                                   // 440
    })                                                                                                    // 441
                                                                                                          // 442
                                                                                                          // 443
    // ignore 'dontStub' packages                                                                         // 444
                                                                                                          // 445
    options = options || {}                                                                               // 446
    dontStub = options.dontStub || []                                                                     // 447
    if ('string' === typeof dontStub) {                                                                   // 448
      dontStub = [dontStub]                                                                               // 449
    }                                                                                                     // 450
                                                                                                          // 451
    _.each(dontStub, function (packageName) {                                                             // 452
      packagesToIgnore.add(packageName)                                                                   // 453
    })                                                                                                    // 454
                                                                                                          // 455
    return packagesToIgnore                                                                               // 456
  },  // end listPackagesToIgnore                                                                         // 457
                                                                                                          // 458
                                                                                                          // 459
  /**                                                                                                     // 460
   * Get the names of all test packages in a given Meteor application.                                    // 461
   * Test packages are identified by having `testPackage: true` in their                                  // 462
   * `smart.json` file.                                                                                   // 463
   *                                                                                                      // 464
   * Used by PackageStubber to identify other packages to ignore.                                         // 465
   *                                                                                                      // 466
   * NOTE: Does not need to be run in a Meteor context.                                                   // 467
   *                                                                                                      // 468
   * @method listTestPackages                                                                             // 469
   * @param {Object} [options]                                                                            // 470
   * @param {String} [options.appDir] Directory path of Meteor application to                             // 471
   *                                  identify test packages for.                                         // 472
   *                                  Default: PWD (process working directory)                            // 473
   * @return {Array} names of all test packages.                                                          // 474
   *                 Ex. ['jasmine-unit', 'mocha-web-velocity']                                           // 475
   */                                                                                                     // 476
  listTestPackages: function (options) {                                                                  // 477
    var smartJsonFiles,                                                                                   // 478
        names = []                                                                                        // 479
                                                                                                          // 480
    options = options || {}                                                                               // 481
    options.appDir = normalizeAppDir(options)                                                             // 482
                                                                                                          // 483
    smartJsonFiles = glob.sync(_p("*/smart.json"),                                                        // 484
                               {cwd: path.join(options.appDir, "packages")})                              // 485
                                                                                                          // 486
    _.each(smartJsonFiles, function (filePath) {                                                          // 487
      var smartJson,                                                                                      // 488
          fullPath = path.join(options.appDir, "packages", filePath)                                      // 489
                                                                                                          // 490
      try {                                                                                               // 491
        smartJson = JSON.parse(fs.readFileSync(fullPath, 'utf8'))                                         // 492
        if (smartJson && smartJson.testPackage) {                                                         // 493
          names.push(path.dirname(filePath))                                                              // 494
        }                                                                                                 // 495
      }                                                                                                   // 496
      catch (ex) {                                                                                        // 497
        DEBUG && console.log('[PackageStubber]', filePath, ex)                                            // 498
      }                                                                                                   // 499
    })                                                                                                    // 500
                                                                                                          // 501
    return names                                                                                          // 502
  },  // end listTestPackages                                                                             // 503
                                                                                                          // 504
                                                                                                          // 505
  /**                                                                                                     // 506
   * Performs a deep copy of the target object, replacing all function fields                             // 507
   * with a string placeholder.                                                                           // 508
   *                                                                                                      // 509
   * @method deepCopyReplaceFn                                                                            // 510
   * @param {Object} target The object that will be stubbed.                                              // 511
   * @param {String} [fnPlaceholder] string to use in place of any function                               // 512
   *                 fields.  Default: "FUNCTION_PLACEHOLDER"                                             // 513
   * @return {Object} new object, with all functions replaced with the                                    // 514
   *                  fnPlaceholder string                                                                // 515
   */                                                                                                     // 516
  deepCopyReplaceFn: function (target, fnPlaceholder) {                                                   // 517
    var dest = {},                                                                                        // 518
        fieldName,                                                                                        // 519
        type                                                                                              // 520
                                                                                                          // 521
    PackageStubber.validate.deepCopyReplaceFn(target, fnPlaceholder)                                      // 522
                                                                                                          // 523
    fnPlaceholder = fnPlaceholder || "FUNCTION_PLACEHOLDER"                                               // 524
                                                                                                          // 525
    for (fieldName in target) {                                                                           // 526
      type = typeof target[fieldName]                                                                     // 527
      switch (type) {                                                                                     // 528
        case "number":                                                                                    // 529
          dest[fieldName] = target[fieldName]                                                             // 530
          break                                                                                           // 531
        case "string":                                                                                    // 532
          dest[fieldName] = target[fieldName]                                                             // 533
          break                                                                                           // 534
        case "function":                                                                                  // 535
          dest[fieldName] = fnPlaceholder                                                                 // 536
          break                                                                                           // 537
        case "object":                                                                                    // 538
          if (target[fieldName] === null) {                                                               // 539
            dest[fieldName] = null                                                                        // 540
          } else if (target[fieldName] instanceof Date) {                                                 // 541
            dest[fieldName] = new Date(target[fieldName])                                                 // 542
          } else {                                                                                        // 543
            dest[fieldName] = PackageStubber.deepCopyReplaceFn(                                           // 544
                                                  target[fieldName],                                      // 545
                                                  fnPlaceholder)                                          // 546
          }                                                                                               // 547
          break                                                                                           // 548
      }                                                                                                   // 549
    }                                                                                                     // 550
                                                                                                          // 551
    return dest                                                                                           // 552
  },  // end deepCopyReplaceFn                                                                            // 553
                                                                                                          // 554
                                                                                                          // 555
  /**                                                                                                     // 556
   * Neither JSON.stringify() nor .toString() work for functions so we "stub"                             // 557
   * functions by:                                                                                        // 558
   *   1. replacing them with a placeholder string                                                        // 559
   *   2. `JSON.stringify`ing the resulting object                                                        // 560
   *   3. converting placeholders to empty function code in string form                                   // 561
   *                                                                                                      // 562
   * We need to do the string replacement in two steps because otherwise the                              // 563
   * `JSON.stringify` step would escape our functions incorrectly.                                        // 564
   *                                                                                                      // 565
   * @method replaceFnPlaceholders                                                                        // 566
   * @param {String} str String to convert                                                                // 567
   * @param {String} [placeHolder] string to replace.                                                     // 568
   *                 Default: "FUNCTION_PLACEHOLDER"                                                      // 569
   * @param {String} [replacement] replacement for placeholder strings.                                   // 570
   *                 Default: PackageStubber.functionReplacementStr                                       // 571
   * @return {String} string with all placeholder strings replaced                                        // 572
   *                  with `PackageStubber.functionReplacementStr`                                        // 573
   */                                                                                                     // 574
  replaceFnPlaceholders: function (str, placeholder, replacement) {                                       // 575
    var regex                                                                                             // 576
                                                                                                          // 577
    placeholder = placeholder || '"FUNCTION_PLACEHOLDER"'                                                 // 578
    replacement = replacement || PackageStubber.functionReplacementStr                                    // 579
                                                                                                          // 580
    regex = new RegExp(placeholder, 'g')                                                                  // 581
                                                                                                          // 582
    return str.replace(regex, replacement)                                                                // 583
  },  // end replaceFnPlaceholders                                                                        // 584
                                                                                                          // 585
                                                                                                          // 586
  stubGenerators: {                                                                                       // 587
                                                                                                          // 588
    /**                                                                                                   // 589
     * Generates a stub in string form for function types.                                                // 590
     *                                                                                                    // 591
     * @method stubGenerators.function                                                                    // 592
     * @param {Function} target Target function to stub                                                   // 593
     * @param {String} name Name of target object for use in reporting errors                             // 594
     * @param {String} package Name of target package for use in errors                                   // 595
     * @return {String} Javascript code in string form which, when executed,                              // 596
     *                  builds the stub in the then-current global context                                // 597
     */                                                                                                   // 598
    'function': function (target, name, package) {                                                        // 599
      var stubInStringForm,                                                                               // 600
          defaultReturnStr = PackageStubber.functionReplacementStr,                                       // 601
          stubGenerator,                                                                                  // 602
          warningMsg                                                                                      // 603
                                                                                                          // 604
      // Attempt to instantiate new constructor with no parameters.                                       // 605
      //   ex. moment().format('MMM dd, YYYY')                                                            // 606
      // Some packages have global function objects which throw an error                                  // 607
      // if no parameters are passed (ex. IronRouter's RouteController).                                  // 608
      // In this case, not much we can do.  Just alert the user and stub                                  // 609
      // with an empty function.                                                                          // 610
                                                                                                          // 611
      warningMsg = function (isError) {                                                                   // 612
        return "[PackageStubber] NOTE: Calling exported function '" +                                     // 613
               name + "' in package '" + package + "' with no parameters " +                              // 614
               (isError ? "threw an error. " : "returned null or undefined. ") +                          // 615
               "'" + name + "' has been stubbed with an empty function " +                                // 616
               "but if you receive errors due to missing fields in " +                                    // 617
               "this package, you will need to supply your own " +                                        // 618
               "custom stub for '" + name + "'. " +                                                       // 619
               "For example, 'tests" + path.sep + package + "-stub.js'.  " +                              // 620
               "Once you have a working stub, please consider contributing " +                            // 621
               "it back to the community stubs in the `package-stubber` repo."                            // 622
      }                                                                                                   // 623
                                                                                                          // 624
      try {                                                                                               // 625
        target = target()                                                                                 // 626
                                                                                                          // 627
        if (!target) {                                                                                    // 628
          console.log(warningMsg())                                                                       // 629
          return defaultReturnStr                                                                         // 630
        }                                                                                                 // 631
                                                                                                          // 632
        stubGenerator = PackageStubber.stubGenerators[typeof target]                                      // 633
        stubInStringForm = stubGenerator(target, name, package)                                           // 634
        stubInStringForm = "function () { return " + stubInStringForm + "; }"                             // 635
        return stubInStringForm                                                                           // 636
      } catch (ex) {                                                                                      // 637
        console.log(warningMsg(true), "The original error was: ", ex.message)                             // 638
        return defaultReturnStr                                                                           // 639
      }                                                                                                   // 640
    },                                                                                                    // 641
                                                                                                          // 642
    /**                                                                                                   // 643
     * Generates a stub in string form for object types.                                                  // 644
     *                                                                                                    // 645
     * @method stubGenerators.object                                                                      // 646
     * @param {Object} target Target object to stub                                                       // 647
     * @param {String} name Name of target object for use in reporting errors                             // 648
     * @param {String} package Name of target package for use in errors                                   // 649
     * @return {String} String representation of the target object.                                       // 650
     */                                                                                                   // 651
    'object': function (target, name, package) {                                                          // 652
      var intermediateStub,                                                                               // 653
          stubInStringForm,                                                                               // 654
          defaultReturnStr = "{}"                                                                         // 655
                                                                                                          // 656
      try {                                                                                               // 657
        intermediateStub = PackageStubber.deepCopyReplaceFn(target)                                       // 658
        stubInStringForm = PackageStubber.replaceFnPlaceholders(                                          // 659
                               JSON.stringify(intermediateStub, null, 2))                                 // 660
        return stubInStringForm                                                                           // 661
      } catch (ex) {                                                                                      // 662
        console.log("[PackageStubber] NOTE: There was an error thrown while'" +                           // 663
               "attempting to generate a stub for '" + name + "' in package '" +                          // 664
               package + "'. " + name + " has been stubbed with an empty " +                              // 665
               "object but if you receive errors due to missing fields in " +                             // 666
               "this package, you will need to supply your own " +                                        // 667
               "custom stub for '" + name + "'. " +                                                       // 668
               "For example, 'tests" + path.sep + package + "-stub.js'.  " +                              // 669
               "Once you have a working stub, please consider contributing " +                            // 670
               "it back to the community stubs in the `package-stubber` repo." +                          // 671
               "The original error was:\n", ex.message)                                                   // 672
        return defaultReturnStr                                                                           // 673
      }                                                                                                   // 674
    },                                                                                                    // 675
                                                                                                          // 676
    /**                                                                                                   // 677
     * Generates a stub in string form for string types.                                                  // 678
     *                                                                                                    // 679
     * @method stubGenerators.string                                                                      // 680
     * @param {Object} target Target string to stub                                                       // 681
     * @param {String} name Name of target string for use in reporting errors                             // 682
     * @return {String} The original target string, passed through                                        // 683
     */                                                                                                   // 684
    'string': function (target, name) {                                                                   // 685
      return target                                                                                       // 686
    },                                                                                                    // 687
                                                                                                          // 688
    /**                                                                                                   // 689
     * Generates a stub in string form for number types.                                                  // 690
     *                                                                                                    // 691
     * @method stubGenerators.number                                                                      // 692
     * @param {Object} target Target number to stub                                                       // 693
     * @param {String} name Name of target number for use in reporting errors                             // 694
     * @return {String} The original target number, converted to a string                                 // 695
     */                                                                                                   // 696
    'number': function (target, name) {                                                                   // 697
      return target.toString()                                                                            // 698
    },                                                                                                    // 699
                                                                                                          // 700
    /**                                                                                                   // 701
     * Generates a stub in string form for undefined targets.                                             // 702
     *                                                                                                    // 703
     * @method stubGenerators.undefined                                                                   // 704
     * @return {String} "undefined"                                                                       // 705
     */                                                                                                   // 706
    'undefined': function () {                                                                            // 707
      return 'undefined'                                                                                  // 708
    }                                                                                                     // 709
                                                                                                          // 710
  },  // end stubGenerators                                                                               // 711
                                                                                                          // 712
                                                                                                          // 713
  /**                                                                                                     // 714
   * Creates a stub of the target object or function.  Stub is in the form                                // 715
   * of js source code in string form which, when executed, builds the stubs                              // 716
   * in the then-current global context.                                                                  // 717
   *                                                                                                      // 718
   * Useful when auto-stubbing Meteor packages and then running unit tests                                // 719
   * in a new, Meteor-free context.                                                                       // 720
   *                                                                                                      // 721
   * @method generateStubSource                                                                           // 722
   * @param {Any} target Target to stub                                                                   // 723
   * @param {String} name Name thing to stub for use in reporting errors                                  // 724
   * @param {String} package Name of target package for use in errors                                     // 725
   * @return {String} Javascript code in string form which, when executed,                                // 726
   *                  builds the stub in the then-current global context                                  // 727
   */                                                                                                     // 728
  generateStubSource: function (target, name, package) {                                                  // 729
    var typeOfTarget = typeof target,                                                                     // 730
        stubGenerator                                                                                     // 731
                                                                                                          // 732
    if (null === target) {                                                                                // 733
      // handle null special case since it has type "object"                                              // 734
      return "null"                                                                                       // 735
    }                                                                                                     // 736
                                                                                                          // 737
    // dispatch to generator function based on type of target                                             // 738
                                                                                                          // 739
    stubGenerator = PackageStubber.stubGenerators[typeOfTarget]                                           // 740
                                                                                                          // 741
    if (!stubGenerator) {                                                                                 // 742
      throw new Error("[PackageStubber] Could not stub package export '" +                                // 743
                      name + "' in package '" + package + "'.  Missing stub " +                           // 744
                      "generator for type", typeOfTarget)                                                 // 745
    }                                                                                                     // 746
                                                                                                          // 747
    return stubGenerator(target, name, package)                                                           // 748
                                                                                                          // 749
  }  // end generateStubSource                                                                            // 750
                                                                                                          // 751
})  // end _.extend PackageStubber                                                                        // 752
                                                                                                          // 753
                                                                                                          // 754
                                                                                                          // 755
/**                                                                                                       // 756
 * List all non-hidden directories in target directory                                                    // 757
 *                                                                                                        // 758
 * @method ls                                                                                             // 759
 * @return {Array} list of all non-hidden directories in target directory                                 // 760
 * @private                                                                                               // 761
 */                                                                                                       // 762
function ls (rootDir) {                                                                                   // 763
  var files = fs.readdirSync(rootDir)                                                                     // 764
                                                                                                          // 765
  return _.reduce(files, function (memo, file) {                                                          // 766
    var filePath,                                                                                         // 767
        stat                                                                                              // 768
                                                                                                          // 769
    if (file[0] != '.') {                                                                                 // 770
      filePath = path.join(rootDir, file)                                                                 // 771
      stat = fs.statSync(filePath)                                                                        // 772
                                                                                                          // 773
      if (stat.isDirectory()) {                                                                           // 774
        memo.push(file)                                                                                   // 775
      }                                                                                                   // 776
    }                                                                                                     // 777
                                                                                                          // 778
    return memo                                                                                           // 779
  }, [])                                                                                                  // 780
}  // end ls                                                                                              // 781
                                                                                                          // 782
                                                                                                          // 783
/**                                                                                                       // 784
 * Normalizes path to application directory.                                                              // 785
 *                                                                                                        // 786
 * @method normalizeAppDir                                                                                // 787
 * @param {Object} [options]                                                                              // 788
 * @param {String} [options.appDir] Directory path of Meteor application to                               // 789
 *                                  identify package exports for.                                         // 790
 *                                  Default: PWD (process working directory)                              // 791
 * @return {String} absolute path to application directory                                                // 792
 */                                                                                                       // 793
function normalizeAppDir (options) {                                                                      // 794
  var pwd = process.env.PWD                                                                               // 795
                                                                                                          // 796
  if (!options || 'string' !== typeof options.appDir) {                                                   // 797
    return pwd                                                                                            // 798
  }                                                                                                       // 799
                                                                                                          // 800
  if (options.appDir && options.appDir[0] !== path.sep) {                                                 // 801
    // relative path, prepend PWD                                                                         // 802
    return path.join(pwd, options.appDir)                                                                 // 803
  }                                                                                                       // 804
                                                                                                          // 805
  return options.appDir                                                                                   // 806
}  // end normalizeAppDir                                                                                 // 807
                                                                                                          // 808
                                                                                                          // 809
/**                                                                                                       // 810
 * Return a cross-platform compatible file path                                                           // 811
 *                                                                                                        // 812
 * @method _p                                                                                             // 813
 * @param {String} filePath                                                                               // 814
 * @return {String} a cross-platform compatible file path                                                 // 815
 * @private                                                                                               // 816
 */                                                                                                       // 817
function _p (filePath) {                                                                                  // 818
  return filePath.replace(/\//g, path.sep)                                                                // 819
}                                                                                                         // 820
                                                                                                          // 821
                                                                                                          // 822
})();                                                                                                     // 823
                                                                                                          // 824
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['package-stubber'] = {
  PackageStubber: PackageStubber
};

})();

//# sourceMappingURL=package-stubber.js.map
