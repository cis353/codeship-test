(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Velocity = Package.velocity.Velocity;
var VelocityTestFiles = Package.velocity.VelocityTestFiles;
var VelocityFixtureFiles = Package.velocity.VelocityFixtureFiles;
var VelocityTestReports = Package.velocity.VelocityTestReports;
var VelocityAggregateReports = Package.velocity.VelocityAggregateReports;
var VelocityLogs = Package.velocity.VelocityLogs;
var VelocityMirrors = Package.velocity.VelocityMirrors;

/* Package-scope variables */
var TEST_FRAMEWORK_NAME, debug;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/jasmine/server/main.js                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
/* global                                                            // 1
   TEST_FRAMEWORK_NAME: true,                                        // 2
   debug: true                                                       // 3
*/                                                                   // 4
TEST_FRAMEWORK_NAME = 'jasmine';                                     // 5
                                                                     // 6
// Debug log helper                                                  // 7
if (process.env.VELOCITY_DEBUG) {                                    // 8
  debug = function () {                                              // 9
    var args = Array.prototype.slice.call(arguments);                // 10
    args[0] = TEST_FRAMEWORK_NAME + ': ' + args[0];                  // 11
    console.log.apply(console, args);                                // 12
  };                                                                 // 13
} else {                                                             // 14
  debug = function noop() {};                                        // 15
}                                                                    // 16
                                                                     // 17
///////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/jasmine/server/fileCopier.js                             //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
/* global                                                            // 1
 TEST_FRAMEWORK_NAME: false,                                         // 2
 Velocity: false                                                     // 3
 */                                                                  // 4
                                                                     // 5
if (process.env.NODE_ENV === 'development') {                        // 6
  Meteor.startup(function () {                                       // 7
    var fileCopier = new Velocity.FileCopier({                       // 8
      targetFramework: TEST_FRAMEWORK_NAME                           // 9
    });                                                              // 10
    fileCopier.start();                                              // 11
  });                                                                // 12
}                                                                    // 13
                                                                     // 14
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.jasmine = {};

})();

//# sourceMappingURL=jasmine.js.map
