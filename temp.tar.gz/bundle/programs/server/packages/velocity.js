(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var check = Package.check.check;
var Match = Package.check.Match;
var HTTP = Package.http.HTTP;
var Retry = Package.retry.Retry;

/* Package-scope variables */
var Velocity, VelocityTestFiles, VelocityFixtureFiles, VelocityTestReports, VelocityAggregateReports, VelocityLogs, VelocityMirrors, DEBUG;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/velocity/collections.js                                                                              //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
/*jshint -W117 */                                                                                                // 1
/* global                                                                                                        // 2
 VelocityTestFiles: true,                                                                                        // 3
 VelocityTestReports: true,                                                                                      // 4
 VelocityAggregateReports: true,                                                                                 // 5
 VelocityLogs: true,                                                                                             // 6
 VelocityMirrors: true                                                                                           // 7
 */                                                                                                              // 8
                                                                                                                 // 9
VelocityTestFiles = new Meteor.Collection('velocityTestFiles');                                                  // 10
VelocityFixtureFiles = new Meteor.Collection('velocityFixtureFiles');                                            // 11
VelocityTestReports = new Meteor.Collection('velocityTestReports');                                              // 12
VelocityAggregateReports = new Meteor.Collection('velocityAggregateReports');                                    // 13
VelocityLogs = new Meteor.Collection('velocityLogs');                                                            // 14
VelocityMirrors = new Meteor.Collection('velocityMirrors');                                                      // 15
                                                                                                                 // 16
(function () {                                                                                                   // 17
  'use strict';                                                                                                  // 18
                                                                                                                 // 19
  if (!Package.autopublish) {                                                                                    // 20
    if (Meteor.isServer) {                                                                                       // 21
      Meteor.publish('VelocityTestFiles', function () {                                                          // 22
        return VelocityTestFiles.find({});                                                                       // 23
      });                                                                                                        // 24
      Meteor.publish('VelocityFixtureFiles', function () {                                                       // 25
        return VelocityFixtureFiles.find({});                                                                    // 26
      });                                                                                                        // 27
      Meteor.publish('VelocityTestReports', function () {                                                        // 28
        return VelocityTestReports.find({});                                                                     // 29
      });                                                                                                        // 30
      Meteor.publish('VelocityAggregateReports', function () {                                                   // 31
        return VelocityAggregateReports.find({});                                                                // 32
      });                                                                                                        // 33
      Meteor.publish('VelocityLogs', function () {                                                               // 34
        return VelocityLogs.find({});                                                                            // 35
      });                                                                                                        // 36
      Meteor.publish('VelocityMirrors', function () {                                                            // 37
        return VelocityMirrors.find({});                                                                         // 38
      });                                                                                                        // 39
    }                                                                                                            // 40
                                                                                                                 // 41
    if (Meteor.isClient) {                                                                                       // 42
      Meteor.subscribe('VelocityTestFiles');                                                                     // 43
      Meteor.subscribe('VelocityFixtureFiles');                                                                  // 44
      Meteor.subscribe('VelocityTestReports');                                                                   // 45
      Meteor.subscribe('VelocityAggregateReports');                                                              // 46
      Meteor.subscribe('VelocityLogs');                                                                          // 47
      Meteor.subscribe('VelocityMirrors');                                                                       // 48
    }                                                                                                            // 49
  }                                                                                                              // 50
})();                                                                                                            // 51
                                                                                                                 // 52
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/velocity/main.js                                                                                     //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
/*jshint -W117, -W030 */                                                                                         // 1
/* global                                                                                                        // 2
 Velocity:true,                                                                                                  // 3
 DEBUG:true                                                                                                      // 4
 */                                                                                                              // 5
                                                                                                                 // 6
DEBUG = !!process.env.VELOCITY_DEBUG;                                                                            // 7
/**                                                                                                              // 8
 * @module Velocity                                                                                              // 9
 */                                                                                                              // 10
/**                                                                                                              // 11
 * @class Velocity                                                                                               // 12
 */                                                                                                              // 13
Velocity = {};                                                                                                   // 14
                                                                                                                 // 15
(function () {                                                                                                   // 16
  'use strict';                                                                                                  // 17
                                                                                                                 // 18
//////////////////////////////////////////////////////////////////////                                           // 19
// Init                                                                                                          // 20
//                                                                                                               // 21
                                                                                                                 // 22
  if (process.env.NODE_ENV !== 'development' || process.env.VELOCITY === '0' || process.env.IS_MIRROR) {         // 23
    DEBUG && console.log('Not adding velocity code');                                                            // 24
    return;                                                                                                      // 25
  }                                                                                                              // 26
                                                                                                                 // 27
  var _ = Npm.require('lodash'),                                                                                 // 28
      fs = Npm.require('fs'),                                                                                    // 29
      fse = Npm.require('fs-extra'),                                                                             // 30
      readFile = Meteor._wrapAsync(fs.readFile),                                                                 // 31
      writeFile = Meteor._wrapAsync(fs.writeFile),                                                               // 32
      copyFile = Meteor._wrapAsync(fse.copy),                                                                    // 33
      path = Npm.require('path'),                                                                                // 34
      url = Npm.require('url'),                                                                                  // 35
      Rsync = Npm.require('rsync'),                                                                              // 36
      Future = Npm.require('fibers/future'),                                                                     // 37
      freeport = Npm.require('freeport'),                                                                        // 38
      child_process = Npm.require('child_process'),                                                              // 39
      spawn = child_process.spawn,                                                                               // 40
      chokidar = Npm.require('chokidar'),                                                                        // 41
      glob = Npm.require('glob'),                                                                                // 42
      _config,                                                                                                   // 43
      _testFrameworks,                                                                                           // 44
      _preProcessors = [],                                                                                       // 45
      _postProcessors = [],                                                                                      // 46
      _watcher,                                                                                                  // 47
      FIXTURE_REG_EXP = new RegExp("-fixture.(js|coffee)$"),                                                     // 48
      DEFAULT_FIXTURE_PATH = process.env.PWD + path.sep + 'packages' + path.sep + 'velocity' + path.sep + 'default-fixture.js';
                                                                                                                 // 50
  Meteor.startup(function initializeVelocity () {                                                                // 51
    DEBUG && console.log('[velocity] PWD', process.env.PWD);                                                     // 52
                                                                                                                 // 53
    _config = _loadTestPackageConfigs();                                                                         // 54
    _testFrameworks = _.pluck(_config, function (config) {                                                       // 55
      return config.name;                                                                                        // 56
    });                                                                                                          // 57
    DEBUG && console.log('velocity config =', JSON.stringify(_config, null, 2));                                 // 58
                                                                                                                 // 59
    // kick-off everything                                                                                       // 60
    _reset(_config);                                                                                             // 61
  });                                                                                                            // 62
                                                                                                                 // 63
//////////////////////////////////////////////////////////////////////                                           // 64
// Public Methods                                                                                                // 65
//                                                                                                               // 66
                                                                                                                 // 67
  _.extend(Velocity, {                                                                                           // 68
                                                                                                                 // 69
    getMirrorPath: function () {                                                                                 // 70
      return path.join(process.env.PWD, '.meteor', 'local', '.mirror');                                          // 71
    },                                                                                                           // 72
                                                                                                                 // 73
    getTestsPath: function () {                                                                                  // 74
      return path.join(process.env.PWD, 'tests');                                                                // 75
    },                                                                                                           // 76
                                                                                                                 // 77
    addPreProcessor: function (preProcessor) {                                                                   // 78
      _preProcessors.push(preProcessor);                                                                         // 79
    },                                                                                                           // 80
                                                                                                                 // 81
    addPostProcessor: function (reporter) {                                                                      // 82
      _postProcessors.push(reporter);                                                                            // 83
    },                                                                                                           // 84
                                                                                                                 // 85
    getReportGithubIssueMessage: function() {                                                                    // 86
      return "Please report the issue here: https://github.com/xolvio/velocity/issues";                          // 87
    }                                                                                                            // 88
  });                                                                                                            // 89
                                                                                                                 // 90
//////////////////////////////////////////////////////////////////////                                           // 91
// Meteor Methods                                                                                                // 92
//                                                                                                               // 93
                                                                                                                 // 94
  Meteor.methods({                                                                                               // 95
                                                                                                                 // 96
    /**                                                                                                          // 97
     * Meteor method: reset                                                                                      // 98
     * Re-init file watcher and clear all test results.                                                          // 99
     *                                                                                                           // 100
     * @method reset                                                                                             // 101
     */                                                                                                          // 102
    reset: function () {                                                                                         // 103
      _reset(_config);                                                                                           // 104
    },                                                                                                           // 105
                                                                                                                 // 106
    /**                                                                                                          // 107
     * Meteor method: resetReports                                                                               // 108
     * Clear all test results.                                                                                   // 109
     *                                                                                                           // 110
     * @method resetReports                                                                                      // 111
     * @param {Object} [options] Optional, specify specific framework to clear                                   // 112
     *                 and/or define a list of tests to keep.                                                    // 113
     *                 ex.                                                                                       // 114
     *                 {                                                                                         // 115
     *                   framework: 'jasmine-unit',                                                              // 116
     *                   notIn: ['tests/auth-jasmine-unit.js']                                                   // 117
     *                 }                                                                                         // 118
     */                                                                                                          // 119
    resetReports: function (options) {                                                                           // 120
      options = options || {};                                                                                   // 121
      check(options, {                                                                                           // 122
        framework: Match.Optional(String),                                                                       // 123
        notIn: Match.Optional([String])                                                                          // 124
      });                                                                                                        // 125
                                                                                                                 // 126
      var query = {};                                                                                            // 127
      if (options.framework) {                                                                                   // 128
        query.framework = options.framework;                                                                     // 129
      }                                                                                                          // 130
      if (options.notIn) {                                                                                       // 131
        query = _.assign(query, {_id: {$nin: options.notIn }});                                                  // 132
      }                                                                                                          // 133
      VelocityTestReports.remove(query);                                                                         // 134
      _updateAggregateReports();                                                                                 // 135
    },                                                                                                           // 136
                                                                                                                 // 137
    /**                                                                                                          // 138
     * Meteor method: resetLogs                                                                                  // 139
     * Clear all log entried.                                                                                    // 140
     *                                                                                                           // 141
     * @method resetLogs                                                                                         // 142
     * @param {Object} [options] Optional, specify specific framework to clear                                   // 143
     */                                                                                                          // 144
    resetLogs: function (options) {                                                                              // 145
      options = options || {};                                                                                   // 146
      check(options, {                                                                                           // 147
        framework: Match.Optional(String)                                                                        // 148
      });                                                                                                        // 149
                                                                                                                 // 150
      var query = {};                                                                                            // 151
      if (options.framework) {                                                                                   // 152
        query.framework = options.framework;                                                                     // 153
      }                                                                                                          // 154
      VelocityLogs.remove(query);                                                                                // 155
    },                                                                                                           // 156
                                                                                                                 // 157
    /**                                                                                                          // 158
     * Meteor method: postLog                                                                                    // 159
     * Log a method to the central Velocity log store.                                                           // 160
     *                                                                                                           // 161
     * @method postLog                                                                                           // 162
     * @param {Object} options Required parameters:                                                              // 163
     *                   type - String                                                                           // 164
     *                   message - String                                                                        // 165
     *                   framework - String  ex. 'jasmine-unit'                                                  // 166
     *                                                                                                           // 167
     *                 Optional parameters:                                                                      // 168
     *                   timestamp - Date                                                                        // 169
     */                                                                                                          // 170
    postLog: function (options) {                                                                                // 171
      check(options, {                                                                                           // 172
        type: String,                                                                                            // 173
        message: String,                                                                                         // 174
        framework: String,                                                                                       // 175
        timestamp: Match.Optional(Match.OneOf(Date, String))                                                     // 176
      });                                                                                                        // 177
                                                                                                                 // 178
      VelocityLogs.insert({                                                                                      // 179
        timestamp: options.timestamp || new Date(),                                                              // 180
        type: options.type,                                                                                      // 181
        message: options.message,                                                                                // 182
        framework: options.framework                                                                             // 183
      });                                                                                                        // 184
    },                                                                                                           // 185
                                                                                                                 // 186
    /**                                                                                                          // 187
     * Meteor method: postResult                                                                                 // 188
     * Record the results of a test run.                                                                         // 189
     *                                                                                                           // 190
     * @method postResult                                                                                        // 191
     * @param {Object} data Required fields:                                                                     // 192
     *                   id - String                                                                             // 193
     *                   name - String                                                                           // 194
     *                   framework - String  ex. 'jasmine-unit'                                                  // 195
     *                   result - String.  ex. 'failed', 'passed' or 'pending'                                   // 196
     *                                                                                                           // 197
     *                 Suggested fields:                                                                         // 198
     *                   isClient - {Boolean] Is it a client test?                                               // 199
     *                   isServer - {Boolean} Is it a server test?                                               // 200
     *                   browser  - {String} In which browser did the test run?                                  // 201
     *                   timestamp - {Date} The time that the test started for this result                       // 202
     *                   async - // TODO @rissem to write                                                        // 203
     *                   timeOut - // TODO @rissem to write                                                      // 204
     *                   failureType - {String} ex 'expect' or 'assert'                                          // 205
     *                   failureMessage - {String} The failure message from the test framework                   // 206
     *                   failureStackTrace - {String} The stack trace associated with the failure                // 207
     *                   ancestors - The hierarchy of suites and blocks above this test                          // 208
     *                               ex. 'Template.leaderboard.selected_name'                                    // 209
     */                                                                                                          // 210
    postResult: function (data) {                                                                                // 211
      check(data, Match.ObjectIncluding({                                                                        // 212
        id: String,                                                                                              // 213
        name: String,                                                                                            // 214
        framework: _matchOneOf(_.keys(_config)),                                                                 // 215
        result: _matchOneOf(['passed', 'failed', 'pending']),                                                    // 216
        isClient: Match.Optional(Boolean),                                                                       // 217
        isServer: Match.Optional(Boolean),                                                                       // 218
        browser: Match.Optional(_matchOneOf(['chrome', 'firefox', 'internet explorer', 'opera', 'safari'])), // TODO: Add missing values
        timestamp: Match.Optional(Match.OneOf(Date, String)),                                                    // 220
        async: Match.Optional(Boolean),                                                                          // 221
        timeOut: Match.Optional(Match.Any),                                                                      // 222
        failureType: Match.Optional(String),                                                                     // 223
        failureMessage: Match.Optional(String),                                                                  // 224
        failureStackTrace: Match.Optional(Match.Any),                                                            // 225
        ancestors: Match.Optional([String])                                                                      // 226
      }));                                                                                                       // 227
                                                                                                                 // 228
      VelocityTestReports.upsert(data.id, {$set: data});                                                         // 229
      _updateAggregateReports();                                                                                 // 230
    },  // end postResult                                                                                        // 231
                                                                                                                 // 232
    /**                                                                                                          // 233
     * Meteor method: completed                                                                                  // 234
     * Frameworks must call this method to inform Velocity they have completed                                   // 235
     * their current test runs. Velocity uses this flag when running in CI mode.                                 // 236
     *                                                                                                           // 237
     * @method completed                                                                                         // 238
     * @param {Object} data Required fields:                                                                     // 239
     *                   framework - String  ex. 'jasmine-unit'                                                  // 240
     */                                                                                                          // 241
    completed: function (data) {                                                                                 // 242
      check(data, {                                                                                              // 243
        framework: String                                                                                        // 244
      });                                                                                                        // 245
                                                                                                                 // 246
      VelocityAggregateReports.upsert({'name': data.framework}, {$set: {'result': 'completed'}});                // 247
      _updateAggregateReports();                                                                                 // 248
    },  // end completed                                                                                         // 249
                                                                                                                 // 250
    /**                                                                                                          // 251
     * Meteor method: copySampleTests                                                                            // 252
     * Copy sample tests from frameworks `sample-tests` directories                                              // 253
     * to user's `app/tests` directory.                                                                          // 254
     *                                                                                                           // 255
     * @method copySampleTests                                                                                   // 256
     * @param {Object} options                                                                                   // 257
     *     ex. {framework: 'jasmine-unit'}                                                                       // 258
     */                                                                                                          // 259
    copySampleTests: function (options) {                                                                        // 260
      var pwd = process.env.PWD,                                                                                 // 261
          samplesPath,                                                                                           // 262
          testsPath,                                                                                             // 263
          command;                                                                                               // 264
                                                                                                                 // 265
      options = options || {};                                                                                   // 266
      check(options, {                                                                                           // 267
        framework: String                                                                                        // 268
      });                                                                                                        // 269
                                                                                                                 // 270
      samplesPath = path.join(pwd, 'packages', options.framework, 'sample-tests');                               // 271
      testsPath = path.join(pwd, 'tests');                                                                       // 272
                                                                                                                 // 273
      DEBUG && console.log('[velocity] checking for sample tests in', path.join(samplesPath, '*'));              // 274
                                                                                                                 // 275
      if (fs.existsSync(samplesPath)) {                                                                          // 276
        command = 'mkdir -p ' + testsPath + ' && ' +                                                             // 277
          'rsync -au ' + path.join(samplesPath, '*') +                                                           // 278
          ' ' + testsPath + path.sep;                                                                            // 279
                                                                                                                 // 280
        DEBUG && console.log('[velocity] copying sample tests (if any) for framework', options.framework, '-', command);
                                                                                                                 // 282
        child_process.exec(command, Meteor.bindEnvironment(                                                      // 283
          function copySampleTestsExecHandler (err, stdout, stderr) {                                            // 284
            if (err) {                                                                                           // 285
              console.log('ERROR', err);                                                                         // 286
            }                                                                                                    // 287
            console.log(stdout);                                                                                 // 288
            console.log(stderr);                                                                                 // 289
          },                                                                                                     // 290
          'copySampleTestsExecHandler'                                                                           // 291
        ));                                                                                                      // 292
      }                                                                                                          // 293
    },  // end copySampleTests                                                                                   // 294
                                                                                                                 // 295
    /**                                                                                                          // 296
     * Meteor method: velocityStartMirror                                                                        // 297
     *                                                                                                           // 298
     * Starts a mirror and copies any specified fixture files into the mirror.                                   // 299
     * TODO and will remove any registered frameworks and reporters from the mirror                              // 300
     *                                                                                                           // 301
     * @method velocityStartMirror                                                                               // 302
     * @param {Object} options Required fields:                                                                  // 303
     *                   name - String ex. 'mocha-web-1'                                                         // 304
     *                                                                                                           // 305
     *                 Optional parameters:                                                                      // 306
     *                   fixtureFiles - Array of files with absolute paths                                       // 307
     *                   port - String use a specific port instead of finding the next available one             // 308
     *                                                                                                           // 309
     * @return the url of started mirror                                                                         // 310
     */                                                                                                          // 311
    velocityStartMirror: function (options) {                                                                    // 312
      check(options, {                                                                                           // 313
        name: String,                                                                                            // 314
        fixtureFiles: Match.Optional([String]),                                                                  // 315
        port: Match.Optional(Number)                                                                             // 316
      });                                                                                                        // 317
                                                                                                                 // 318
      var port = options.port || Meteor._wrapAsync(freeport)();                                                  // 319
      var mongoLocation = _getMongoUrl(options.name);                                                            // 320
      var mirrorLocation = _getMirrorUrl(port);                                                                  // 321
                                                                                                                 // 322
      if (options.fixtureFiles) {                                                                                // 323
        _addFixtures(options.fixtureFiles);                                                                      // 324
      }                                                                                                          // 325
                                                                                                                 // 326
      var opts = {                                                                                               // 327
        cwd: Velocity.getMirrorPath(),                                                                           // 328
        stdio: 'pipe',                                                                                           // 329
        env: _.extend({}, process.env, {                                                                         // 330
          ROOT_URL: mirrorLocation,                                                                              // 331
          MONGO_URL: mongoLocation,                                                                              // 332
          PARENT_URL: process.env.ROOT_URL,                                                                      // 333
          IS_MIRROR: true                                                                                        // 334
        })                                                                                                       // 335
      };                                                                                                         // 336
                                                                                                                 // 337
      writeFile(Velocity.getMirrorPath() + '/settings.json', JSON.stringify(Meteor.settings));                   // 338
                                                                                                                 // 339
      DEBUG && console.log('[velocity] Mirror: starting at', mirrorLocation);                                    // 340
                                                                                                                 // 341
      var spawnAttempts = 10;                                                                                    // 342
      var spawnMeteor = function () {                                                                            // 343
        var closeHandler = function (code, signal) {                                                             // 344
          console.log('[velocity] Mirror: exited with code ' + code + ' signal ' + signal);                      // 345
          setTimeout(function () {                                                                               // 346
            console.log('[velocity] Mirror: trying to restart');                                                 // 347
            spawnAttempts--;                                                                                     // 348
            if (spawnAttempts) {                                                                                 // 349
              spawnMeteor();                                                                                     // 350
            } else {                                                                                             // 351
              console.error('[velocity] Mirror: could not be started on port ' + port + '.\n' +                  // 352
                'Please make sure that nothing else is using the port and then restart your app to try again.'); // 353
            }                                                                                                    // 354
          }, 1000);                                                                                              // 355
        };                                                                                                       // 356
        var meteor = spawn(                                                                                      // 357
          'meteor',                                                                                              // 358
          ['--port', port, '--settings', 'settings.json'],                                                       // 359
          opts                                                                                                   // 360
        );                                                                                                       // 361
        meteor.on('close', closeHandler);                                                                        // 362
                                                                                                                 // 363
        if (!!process.env.VELOCITY_DEBUG_MIRROR) {                                                               // 364
          var outputHandler = function (data) {                                                                  // 365
            var lines = data.toString().split(/\r?\n/).slice(0, -1);                                             // 366
            _.map(lines, function (line) {                                                                       // 367
              console.log('[velocity mirror] ' + line);                                                          // 368
            });                                                                                                  // 369
          };                                                                                                     // 370
          meteor.stdout.on('data', outputHandler);                                                               // 371
          meteor.stderr.on('data', outputHandler);                                                               // 372
        }                                                                                                        // 373
      };                                                                                                         // 374
      spawnMeteor();                                                                                             // 375
                                                                                                                 // 376
      var storeMirrorMetadata = function () {                                                                    // 377
        VelocityMirrors.insert({                                                                                 // 378
          framework: options.framework,                                                                          // 379
          name: options.name,                                                                                    // 380
          port: port,                                                                                            // 381
          rootUrl: mirrorLocation,                                                                               // 382
          mongoUrl: mongoLocation                                                                                // 383
        });                                                                                                      // 384
      };                                                                                                         // 385
                                                                                                                 // 386
      return _retryHttpGet(mirrorLocation, {url: mirrorLocation, port: port}, function (statusCode) {            // 387
        if (statusCode === 200) {                                                                                // 388
          storeMirrorMetadata();                                                                                 // 389
        } else {                                                                                                 // 390
          console.error('Mirror did not start correctly. Status code was ', statusCode);                         // 391
        }                                                                                                        // 392
      });                                                                                                        // 393
                                                                                                                 // 394
    },  // end velocityStartMirror                                                                               // 395
                                                                                                                 // 396
                                                                                                                 // 397
    /**                                                                                                          // 398
     * Meteor method: velocityIsMirror                                                                           // 399
     * Exposes the IS_MIRROR flag to clients                                                                     // 400
     *                                                                                                           // 401
     * @method velocityIsMirror                                                                                  // 402
     */                                                                                                          // 403
    velocityIsMirror: function () {                                                                              // 404
      return !!process.env.IS_MIRROR;                                                                            // 405
    }                                                                                                            // 406
                                                                                                                 // 407
  });  // end Meteor methods                                                                                     // 408
                                                                                                                 // 409
//////////////////////////////////////////////////////////////////////                                           // 410
// Private functions                                                                                             // 411
//                                                                                                               // 412
                                                                                                                 // 413
  /**                                                                                                            // 414
   * Returns the MongoDB URL for the given database.                                                             // 415
   * @param database                                                                                             // 416
   * @returns {string} MongoDB Url                                                                               // 417
   * @private                                                                                                    // 418
   */                                                                                                            // 419
  function _getMongoUrl (database) {                                                                             // 420
    var mongoLocationParts = url.parse(process.env.MONGO_URL);                                                   // 421
    var mongoLocation = url.format({                                                                             // 422
      protocol: mongoLocationParts.protocol,                                                                     // 423
      slashes: mongoLocationParts.slashes,                                                                       // 424
      hostname: mongoLocationParts.hostname,                                                                     // 425
      port: mongoLocationParts.port,                                                                             // 426
      pathname: '/' + database                                                                                   // 427
    });                                                                                                          // 428
    return mongoLocation;                                                                                        // 429
  }                                                                                                              // 430
                                                                                                                 // 431
  /**                                                                                                            // 432
   * Return URL for the mirror with the given port.                                                              // 433
   * @param port Mirror port                                                                                     // 434
   * @returns {string} Mirror URL                                                                                // 435
   * @private                                                                                                    // 436
   */                                                                                                            // 437
  function _getMirrorUrl (port) {                                                                                // 438
    var rootUrlParts = url.parse(Meteor.absoluteUrl());                                                          // 439
    var mirrorLocation = url.format({                                                                            // 440
      protocol: rootUrlParts.protocol,                                                                           // 441
      slashes: rootUrlParts.slashes,                                                                             // 442
      hostname: rootUrlParts.hostname,                                                                           // 443
      port: port,                                                                                                // 444
      pathname: rootUrlParts.pathname                                                                            // 445
    });                                                                                                          // 446
    return mirrorLocation;                                                                                       // 447
  }                                                                                                              // 448
                                                                                                                 // 449
  /**                                                                                                            // 450
   * Add fixtures to the database.                                                                               // 451
   * @param fixtureFiles Array with fixture file paths.                                                          // 452
   * @private                                                                                                    // 453
   */                                                                                                            // 454
  function _addFixtures (fixtureFiles) {                                                                         // 455
    _.each(fixtureFiles, function (fixtureFile) {                                                                // 456
      VelocityFixtureFiles.insert({                                                                              // 457
        _id: fixtureFile,                                                                                        // 458
        absolutePath: fixtureFile                                                                                // 459
      });                                                                                                        // 460
    });                                                                                                          // 461
  }                                                                                                              // 462
                                                                                                                 // 463
  /**                                                                                                            // 464
   *                                                                                                             // 465
   * Performs a http get and retries the specified number of times with the specified timeouts.                  // 466
   * Uses a future to respond and the future return object can be provided.                                      // 467
   *                                                                                                             // 468
   * @method _retryHttpGet                                                                                       // 469
   * @param url                   requiredFields  The target location                                            // 470
   *                                                                                                             // 471
   * @param futureResponse        optional        The future response that will be augmented with the            // 472
   *                                              http status code (if successful)                               // 473
   * @param preResponseCallback   optional        Maximum number of retries                                      // 474
   * @param retries               optional        Maximum number of retries                                      // 475
   * @param maxTimeout            optional        Maximum time to wait for the location to respond               // 476
   *                                                                                                             // 477
   * @return    A future that can be used in meteor methods (or for other async needs)                           // 478
   * @private                                                                                                    // 479
   */                                                                                                            // 480
  function _retryHttpGet (url, futureResponse, preResponseCallback, retries, maxTimeout) {                       // 481
    var f = new Future();                                                                                        // 482
    var retry = new Retry({                                                                                      // 483
      baseTimeout: 100,                                                                                          // 484
      maxTimeout: maxTimeout ? maxTimeout : 1000                                                                 // 485
    });                                                                                                          // 486
    var tries = 0;                                                                                               // 487
    var doGet = function () {                                                                                    // 488
      try {                                                                                                      // 489
        var res = HTTP.get(url);                                                                                 // 490
        preResponseCallback && preResponseCallback(res.statusCode);                                              // 491
        f.return(_.extend({                                                                                      // 492
          statusCode: res.statusCode                                                                             // 493
        }, futureResponse));                                                                                     // 494
      } catch (ex) {                                                                                             // 495
        if (tries < retries ? retries : 5) {                                                                     // 496
          DEBUG && console.log('[velocity] retrying mirror at ', url, ex.message);                               // 497
          retry.retryLater(++tries, doGet);                                                                      // 498
        } else {                                                                                                 // 499
          console.error('[velocity] mirror failed to respond', ex.message);                                      // 500
          f.throw(ex);                                                                                           // 501
        }                                                                                                        // 502
      }                                                                                                          // 503
    };                                                                                                           // 504
    doGet();                                                                                                     // 505
    return f.wait();                                                                                             // 506
  } // end _retryHttpGet                                                                                         // 507
                                                                                                                 // 508
  /**                                                                                                            // 509
   * Matcher for checking if a value is one of the given values.                                                 // 510
   * @param {Array} values Valid values.                                                                         // 511
   * @returns {*}                                                                                                // 512
   * @private                                                                                                    // 513
   */                                                                                                            // 514
  function _matchOneOf (values) {                                                                                // 515
    return Match.Where(function (value) {                                                                        // 516
      return (values.indexOf(value) !== -1);                                                                     // 517
    });                                                                                                          // 518
  }                                                                                                              // 519
                                                                                                                 // 520
  /**                                                                                                            // 521
   * Locate all velocity-compatible test packages and return their config                                        // 522
   * data.                                                                                                       // 523
   *                                                                                                             // 524
   * @example                                                                                                    // 525
   *     // in `jasmine-unit` package's `smart.json`:                                                            // 526
   *     {                                                                                                       // 527
   *       "name": "jasmine-unit",                                                                               // 528
   *       "description": "Velocity-compatible jasmine unit test package",                                       // 529
   *       "homepage": "https://github.com/xolvio/jasmine-unit",                                                 // 530
   *       "author": "Sam Hatoum",                                                                               // 531
   *       "version": "0.1.1",                                                                                   // 532
   *       "git": "https://github.com/xolvio/jasmine-unit.git",                                                  // 533
   *       "test-package": true,                                                                                 // 534
   *       "regex": "-jasmine-unit\\.(js|coffee)$"                                                               // 535
   *     }                                                                                                       // 536
   *                                                                                                             // 537
   * @method _loadTestPackageConfigs                                                                             // 538
   * @return {Object} Hash of test package names and their normalized config data.                               // 539
   * @private                                                                                                    // 540
   */                                                                                                            // 541
  function _loadTestPackageConfigs () {                                                                          // 542
    var pwd = process.env.PWD,                                                                                   // 543
        smartJsons = glob.sync('packages/*/smart.json', {cwd: pwd}),                                             // 544
        testConfigDictionary;                                                                                    // 545
                                                                                                                 // 546
    DEBUG && console.log('Check for test package configs...', smartJsons);                                       // 547
                                                                                                                 // 548
    testConfigDictionary = _.reduce(smartJsons, function (memo, smartJsonPath) {                                 // 549
      var contents,                                                                                              // 550
          config;                                                                                                // 551
                                                                                                                 // 552
      try {                                                                                                      // 553
        contents = readFile(path.join(pwd, smartJsonPath));                                                      // 554
        config = JSON.parse(contents);                                                                           // 555
        if (config.name && config.testPackage) {                                                                 // 556
                                                                                                                 // 557
          // add smart.json contents to our dictionary                                                           // 558
          memo[config.name] = config;                                                                            // 559
                                                                                                                 // 560
          if ('undefined' === typeof memo[config.name].regex) {                                                  // 561
            // if test package hasn't defined an explicit regex for the file                                     // 562
            // watcher, default to the package name as a suffix.                                                 // 563
            // Ex. name = "mocha-web"                                                                            // 564
            //     regex = "-mocha-web.js"                                                                       // 565
            memo[config.name].regex = '-' + config.name + '\\.js$';                                              // 566
          }                                                                                                      // 567
                                                                                                                 // 568
          // create a regexp obj for use in file watching                                                        // 569
          memo[config.name]._regexp = new RegExp(memo[config.name].regex);                                       // 570
        }                                                                                                        // 571
      } catch (ex) {                                                                                             // 572
        DEBUG && console.log('Error reading file:', smartJsonPath, ex);                                          // 573
      }                                                                                                          // 574
      return memo;                                                                                               // 575
    }, {});                                                                                                      // 576
                                                                                                                 // 577
    return testConfigDictionary;                                                                                 // 578
  }  // end _loadTestPackageConfigs                                                                              // 579
                                                                                                                 // 580
  /**                                                                                                            // 581
   * Initialize the directory/file watcher.                                                                      // 582
   *                                                                                                             // 583
   * @method _initWatcher                                                                                        // 584
   * @param {Object} config  See `_loadTestPackageConfigs`.                                                      // 585
   * @private                                                                                                    // 586
   */                                                                                                            // 587
  function _initWatcher (config) {                                                                               // 588
                                                                                                                 // 589
    _watcher = chokidar.watch(Velocity.getTestsPath(), {ignored: /[\/\\]\./});                                   // 590
                                                                                                                 // 591
    _watcher.on('add', Meteor.bindEnvironment(function (filePath) {                                              // 592
      var relativePath,                                                                                          // 593
          targetFramework,                                                                                       // 594
          data;                                                                                                  // 595
                                                                                                                 // 596
      filePath = path.normalize(filePath);                                                                       // 597
                                                                                                                 // 598
      DEBUG && console.log('File added:', filePath);                                                             // 599
                                                                                                                 // 600
      relativePath = filePath.substring(process.env.PWD.length);                                                 // 601
      if (relativePath[0] === path.sep) {                                                                        // 602
        relativePath = relativePath.substring(1);                                                                // 603
      }                                                                                                          // 604
                                                                                                                 // 605
      // if this is a fixture file, put it in the fixtures collection                                            // 606
      if (FIXTURE_REG_EXP.test(relativePath)) {                                                                  // 607
        VelocityFixtureFiles.insert({                                                                            // 608
          _id: filePath,                                                                                         // 609
          absolutePath: filePath,                                                                                // 610
          lastModified: Date.now()                                                                               // 611
        });                                                                                                      // 612
        return;                                                                                                  // 613
      }                                                                                                          // 614
                                                                                                                 // 615
      // test against each test framework's regexp matcher, use first                                            // 616
      // one that matches                                                                                        // 617
      targetFramework = _.find(config, function (framework) {                                                    // 618
        return framework._regexp.test(relativePath);                                                             // 619
      });                                                                                                        // 620
                                                                                                                 // 621
      if (targetFramework) {                                                                                     // 622
        DEBUG && console.log(targetFramework.name, ' <= ', filePath);                                            // 623
                                                                                                                 // 624
        data = {                                                                                                 // 625
          _id: filePath,                                                                                         // 626
          name: path.basename(filePath),                                                                         // 627
          absolutePath: filePath,                                                                                // 628
          relativePath: relativePath,                                                                            // 629
          targetFramework: targetFramework.name,                                                                 // 630
          lastModified: Date.now()                                                                               // 631
        };                                                                                                       // 632
                                                                                                                 // 633
        //DEBUG && console.log('data', data);                                                                    // 634
        VelocityTestFiles.insert(data);                                                                          // 635
      }                                                                                                          // 636
    }));  // end watcher.on 'add'                                                                                // 637
                                                                                                                 // 638
    _watcher.on('change', Meteor.bindEnvironment(function (filePath) {                                           // 639
      DEBUG && console.log('File changed:', filePath);                                                           // 640
                                                                                                                 // 641
      // Since we key on filePath and we only add files we're interested in,                                     // 642
      // we don't have to worry about inadvertently updating records for files                                   // 643
      // we don't care about.                                                                                    // 644
      VelocityFixtureFiles.update(filePath, { $set: {lastModified: Date.now()}});                                // 645
      VelocityTestFiles.update(filePath, { $set: {lastModified: Date.now()}});                                   // 646
    }));                                                                                                         // 647
                                                                                                                 // 648
    _watcher.on('unlink', Meteor.bindEnvironment(function (filePath) {                                           // 649
      DEBUG && console.log('File removed:', filePath);                                                           // 650
      // If we only remove the file, we also need to remove the test results for                                 // 651
      // just that file. This required changing the postResult API and we could                                  // 652
      // do it, but the brute force method of reset() will do the trick until we                                 // 653
      // want to optimize VelocityTestFiles.remove(filePath);                                                    // 654
      _reset(config);                                                                                            // 655
    }));                                                                                                         // 656
                                                                                                                 // 657
  }  // end _initWatcher                                                                                         // 658
                                                                                                                 // 659
  /**                                                                                                            // 660
   * Re-init file watcher and clear all test results.                                                            // 661
   *                                                                                                             // 662
   * @method _reset                                                                                              // 663
   * @param {Object} config  See `_loadTestPackageConfigs`.                                                      // 664
   * @private                                                                                                    // 665
   */                                                                                                            // 666
  function _reset (config) {                                                                                     // 667
    if (_watcher) {                                                                                              // 668
      _watcher.close();                                                                                          // 669
    }                                                                                                            // 670
                                                                                                                 // 671
    VelocityTestFiles.remove({});                                                                                // 672
    VelocityFixtureFiles.remove({});                                                                             // 673
    VelocityFixtureFiles.insert({                                                                                // 674
      _id: DEFAULT_FIXTURE_PATH,                                                                                 // 675
      absolutePath: DEFAULT_FIXTURE_PATH                                                                         // 676
    });                                                                                                          // 677
    VelocityTestReports.remove({});                                                                              // 678
    VelocityLogs.remove({});                                                                                     // 679
    VelocityAggregateReports.remove({});                                                                         // 680
    VelocityAggregateReports.insert({                                                                            // 681
      name: 'aggregateResult',                                                                                   // 682
      result: 'pending'                                                                                          // 683
    });                                                                                                          // 684
    VelocityAggregateReports.insert({                                                                            // 685
      name: 'aggregateComplete',                                                                                 // 686
      result: 'pending'                                                                                          // 687
    });                                                                                                          // 688
    _.each(_testFrameworks, function (testFramework) {                                                           // 689
      VelocityAggregateReports.insert({                                                                          // 690
        name: testFramework,                                                                                     // 691
        result: 'pending'                                                                                        // 692
      });                                                                                                        // 693
    });                                                                                                          // 694
    VelocityMirrors.remove({});                                                                                  // 695
                                                                                                                 // 696
    // Meteor just reloaded us which means we should rsync the app files to the mirror                           // 697
    _syncMirror();                                                                                               // 698
                                                                                                                 // 699
    _initWatcher(config);                                                                                        // 700
  }                                                                                                              // 701
                                                                                                                 // 702
  /**                                                                                                            // 703
   * If any one test has failed, mark the aggregate test result as failed.                                       // 704
   *                                                                                                             // 705
   * @method _updateAggregateReports                                                                             // 706
   * @private                                                                                                    // 707
   */                                                                                                            // 708
  function _updateAggregateReports () {                                                                          // 709
                                                                                                                 // 710
    var failedResult,                                                                                            // 711
        result;                                                                                                  // 712
                                                                                                                 // 713
    if (!VelocityTestReports.findOne({result: ''})) {                                                            // 714
      failedResult = VelocityTestReports.findOne({result: 'failed'});                                            // 715
      result = failedResult ? 'failed' : 'passed';                                                               // 716
                                                                                                                 // 717
      VelocityAggregateReports.update({ 'name': 'aggregateResult'}, {$set: {result: result}});                   // 718
    }                                                                                                            // 719
                                                                                                                 // 720
    // if all test frameworks have completed, upsert an aggregate completed record                               // 721
    var completedFrameworksCount = VelocityAggregateReports.find({ 'name': {$in: _testFrameworks}, 'result': 'completed'}).count();
                                                                                                                 // 723
    if (VelocityAggregateReports.findOne({'name': 'aggregateComplete'}).result !== 'completed' && _testFrameworks.length === completedFrameworksCount) {
      VelocityAggregateReports.update({'name': 'aggregateComplete'}, {$set: {'result': 'completed'}});           // 725
                                                                                                                 // 726
      _.each(_postProcessors, function (reporter) {                                                              // 727
        reporter();                                                                                              // 728
      });                                                                                                        // 729
                                                                                                                 // 730
    }                                                                                                            // 731
                                                                                                                 // 732
  }                                                                                                              // 733
                                                                                                                 // 734
  /**                                                                                                            // 735
   * Creates a physical mirror of the application under .meteor/local/.mirror                                    // 736
   *                                                                                                             // 737
   *     - Any files with the pattern tests/.*  are not copied, this stops .report                               // 738
   *     directory from also being copied.                                                                       // 739
   *                                                                                                             // 740
   *     TODO - Strips out velocity, any test packages and reporters from the mirror's .meteor/packages file     // 741
   *                                                                                                             // 742
   * @method _syncMirror                                                                                         // 743
   * @private                                                                                                    // 744
   */                                                                                                            // 745
  function _syncMirror () {                                                                                      // 746
    var cmd = new Rsync()                                                                                        // 747
      .shell('ssh')                                                                                              // 748
      .flags('av')                                                                                               // 749
      .set('delete')                                                                                             // 750
      .set('q')                                                                                                  // 751
      .set('delay-updates')                                                                                      // 752
      .set('force')                                                                                              // 753
      .exclude('.meteor/local')                                                                                  // 754
      .exclude('tests/.*')                                                                                       // 755
      .source(process.env.PWD + path.sep)                                                                        // 756
      .destination(Velocity.getMirrorPath());                                                                    // 757
    var then = Date.now();                                                                                       // 758
    cmd.execute(Meteor.bindEnvironment(function (error) {                                                        // 759
                                                                                                                 // 760
      if (error) {                                                                                               // 761
        DEBUG && console.error('[velocity] Error syncing mirror', error);                                        // 762
      } else {                                                                                                   // 763
        DEBUG && console.log('[velocity] rsync took', Date.now() - then);                                        // 764
      }                                                                                                          // 765
                                                                                                                 // 766
      _.each(_preProcessors, function (preProcessor) {                                                           // 767
        preProcessor();                                                                                          // 768
      });                                                                                                        // 769
                                                                                                                 // 770
      VelocityFixtureFiles.find({}).forEach(function (fixture) {                                                 // 771
        var fixtureLocationInMirror = Velocity.getMirrorPath() + path.sep + path.basename(fixture.absolutePath) + path.extname(fixture.absolutePath);
        DEBUG && console.log('[velocity] copying fixture', fixture.absolutePath, 'to', fixtureLocationInMirror); // 773
        copyFile(fixture.absolutePath, fixtureLocationInMirror);                                                 // 774
      });                                                                                                        // 775
                                                                                                                 // 776
      // TODO remove this once jasmine and mocha-web are using the velocityStartMirror                           // 777
      Meteor.call('velocityStartMirror', {                                                                       // 778
        name: 'mocha-web',                                                                                       // 779
        port: 5000                                                                                               // 780
      }, function (e, r) {                                                                                       // 781
        if (e) {                                                                                                 // 782
          console.error('[velocity] mirror failed to start', e);                                                 // 783
        } else {                                                                                                 // 784
          console.log('[velocity] Mirror started', r);                                                           // 785
        }                                                                                                        // 786
      });                                                                                                        // 787
                                                                                                                 // 788
    }));                                                                                                         // 789
  }                                                                                                              // 790
                                                                                                                 // 791
})();                                                                                                            // 792
                                                                                                                 // 793
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/velocity/lib/FileCopier.js                                                                           //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
'use strict';                                                                                                    // 1
                                                                                                                 // 2
var _ = Npm.require('lodash');                                                                                   // 3
var path = Npm.require('path');                                                                                  // 4
var fs = Npm.require('fs-extra');                                                                                // 5
var removeFile = Meteor._wrapAsync(fs.remove);                                                                   // 6
var copyFile = Meteor._wrapAsync(fs.copy);                                                                       // 7
                                                                                                                 // 8
/**                                                                                                              // 9
 * Worker that copies test files to the mirror reactively.                                                       // 10
 *                                                                                                               // 11
 * @class FileCopier                                                                                             // 12
 * @constructor                                                                                                  // 13
 * @param {object} options                                                                                       // 14
 * @param {string} options.targetFramework The name of the target framework                                      // 15
 *                                         for which the tests should be copied                                  // 16
 *                                         to the mirror.                                                        // 17
 * @param {function} [options.onFileAdded] Callback that is called after a                                       // 18
 *                                         file was added.                                                       // 19
 * @param {function} [options.onFileChanged] Callback that is called after a                                     // 20
 *                                           file has changed.                                                   // 21
 * @param {function} [options.onFileRemoved] Callback that is called after a                                     // 22
 *                                           file was removed.                                                   // 23
 * @param {function} [options.shouldCopy] Control whether a file is copied.                                      // 24
 *                                        Passed the file object from the                                        // 25
 *                                        VelocityTestFiles collection which                                     // 26
 *                                        has a `absolutePath` field.                                            // 27
 *                                        Default: true                                                          // 28
 *                                                                                                               // 29
 * @example                                                                                                      // 30
 *     var fileCopier = new Velocity.FileCopier({                                                                // 31
 *       targetFramework: TEST_FRAMEWORK_NAME                                                                    // 32
 *     });                                                                                                       // 33
 *     fileCopier.start();                                                                                       // 34
 */                                                                                                              // 35
Velocity.FileCopier = function VelocityFileCopier(options) {                                                     // 36
  check(options, {                                                                                               // 37
    targetFramework: String,                                                                                     // 38
    onFileAdded: Match.Optional(Function),                                                                       // 39
    onFileChanged: Match.Optional(Function),                                                                     // 40
    onFileRemoved: Match.Optional(Function),                                                                     // 41
    shouldCopy: Match.Optional(Function)                                                                         // 42
  });                                                                                                            // 43
  this.options = _.extend({                                                                                      // 44
    onFileAdded: _.noop,                                                                                         // 45
    onFileChanged: _.noop,                                                                                       // 46
    onFileRemoved: _.noop,                                                                                       // 47
    shouldCopy: function () { return true; }                                                                     // 48
  }, options);                                                                                                   // 49
};                                                                                                               // 50
                                                                                                                 // 51
_.extend(Velocity.FileCopier.prototype, {                                                                        // 52
                                                                                                                 // 53
  /**                                                                                                            // 54
   * Starts copying files to the mirror.                                                                         // 55
   *                                                                                                             // 56
   * @method start                                                                                               // 57
   * @memberof Velocity.FileCopier.prototype                                                                     // 58
   */                                                                                                            // 59
  start: function () {                                                                                           // 60
    if (!this._observer) {                                                                                       // 61
      var testFilesCursor = VelocityTestFiles.find({                                                             // 62
        targetFramework: this.options.targetFramework                                                            // 63
      });                                                                                                        // 64
                                                                                                                 // 65
      this._observer = testFilesCursor.observe({                                                                 // 66
        added: this._onFileAdded.bind(this),                                                                     // 67
        changed: this._onFileChanged.bind(this),                                                                 // 68
        removed: this._onFileRemoved.bind(this)                                                                  // 69
      });                                                                                                        // 70
    }                                                                                                            // 71
  },                                                                                                             // 72
                                                                                                                 // 73
  /**                                                                                                            // 74
   * Stops copying files to the mirror.                                                                          // 75
   * @memberof Velocity.FileCopier.prototype                                                                     // 76
   */                                                                                                            // 77
  stop: function () {                                                                                            // 78
    this._observer.stop();                                                                                       // 79
    this._observer = null;                                                                                       // 80
  },                                                                                                             // 81
                                                                                                                 // 82
  _onFileAdded: function _onFileAdded(newFile) {                                                                 // 83
    if (this.options.shouldCopy(newFile)) {                                                                      // 84
      this._replaceFileInMirror(newFile);                                                                        // 85
      this.options.onFileAdded(newFile);                                                                         // 86
    }                                                                                                            // 87
  },                                                                                                             // 88
                                                                                                                 // 89
  _onFileChanged: function _onFileChanged(newFile, oldFile) {                                                    // 90
    // Remove the oldFile in case the absolutePath has changed                                                   // 91
    this._removeFileFromMirror(oldFile);                                                                         // 92
    if (this.options.shouldCopy(newFile)) {                                                                      // 93
      this._replaceFileInMirror(newFile);                                                                        // 94
      this.options.onFileAdded(oldFile, newFile);                                                                // 95
    }                                                                                                            // 96
  },                                                                                                             // 97
                                                                                                                 // 98
  _onFileRemoved: function _onFileRemoved(removedFile) {                                                         // 99
    this._removeFileFromMirror(removedFile);                                                                     // 100
    this.options.onFileRemoved(removedFile);                                                                     // 101
  },                                                                                                             // 102
                                                                                                                 // 103
  _removeFileFromMirror: function _removeFileFromMirror(file) {                                                  // 104
    var mirrorFilePath = this._convertTestsPathToMirrorPath(file.absolutePath);                                  // 105
    DEBUG && console.log('[Velocity.FileCopier] Remove file from mirror', mirrorFilePath);                       // 106
    removeFile(mirrorFilePath);                                                                                  // 107
  },                                                                                                             // 108
                                                                                                                 // 109
  _replaceFileInMirror: function _replaceFileInMirror(file) {                                                    // 110
    var self = this;                                                                                             // 111
                                                                                                                 // 112
    var mirrorFilePath = self._convertTestsPathToMirrorPath(file.absolutePath);                                  // 113
    DEBUG && console.log('[Velocity.FileCopier] Replace file in mirror', mirrorFilePath);                        // 114
    copyFile(file.absolutePath, mirrorFilePath);                                                                 // 115
  },                                                                                                             // 116
                                                                                                                 // 117
  _isInTestsPath: function _isInTestsPath(filePath) {                                                            // 118
    var testsPath = Velocity.getTestsPath();                                                                     // 119
    return filePath.substr(0, testsPath.length) === testsPath;                                                   // 120
  },                                                                                                             // 121
                                                                                                                 // 122
  _convertTestsPathToMirrorPath: function _convertTestsPathToMirrorPath(filePath) {                              // 123
    if (!this._isInTestsPath(filePath)) {                                                                        // 124
      throw new Error('[Velocity.FileCopier] Path "' + filePath + '" is not in the tests path.');                // 125
    }                                                                                                            // 126
                                                                                                                 // 127
    filePath = filePath.substr(Velocity.getTestsPath().length);                                                  // 128
    var targetFramework = this.options.targetFramework;                                                          // 129
    filePath = filePath.replace(targetFramework + '/client', 'client/' + targetFramework);                       // 130
    filePath = filePath.replace(targetFramework + '/server', 'server/' + targetFramework);                       // 131
                                                                                                                 // 132
    return Velocity.getMirrorPath() + filePath;                                                                  // 133
  }                                                                                                              // 134
});                                                                                                              // 135
                                                                                                                 // 136
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.velocity = {
  Velocity: Velocity,
  VelocityTestFiles: VelocityTestFiles,
  VelocityFixtureFiles: VelocityFixtureFiles,
  VelocityTestReports: VelocityTestReports,
  VelocityAggregateReports: VelocityAggregateReports,
  VelocityLogs: VelocityLogs,
  VelocityMirrors: VelocityMirrors
};

})();

//# sourceMappingURL=velocity.js.map
