(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['velocity-html-reporter'] = {};

})();

//# sourceMappingURL=velocity-html-reporter.js.map
