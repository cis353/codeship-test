(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var MochaWeb = Package['mocha-web-velocity'].MochaWeb;
var MeteorCollectionTestReporter = Package['mocha-web-velocity'].MeteorCollectionTestReporter;

/* Package-scope variables */
var QuickStart, packageMap;

(function () {

//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
// packages/velocity-quick-start/quick-start.js                                 //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////
                                                                                //
QuickStart = function () {}                                                     // 1
                                                                                // 2
"use strict";                                                                   // 3
                                                                                // 4
var pwd = process.env.PWD,                                                      // 5
    DEBUG = process.env.DEBUG,                                                  // 6
    fs = Npm.require('fs'),                                                     // 7
    path = Npm.require('path'),                                                 // 8
    rimraf = Npm.require('rimraf'),                                             // 9
    exec = Npm.require('rolling_timeout_exec').exec;                            // 10
                                                                                // 11
                                                                                // 12
_.extend(QuickStart.prototype, {                                                // 13
                                                                                // 14
  exec: function (testPackages) {                                               // 15
    DEBUG && console.log("[velocity-quick-start] executed");                    // 16
                                                                                // 17
    this.copySampleTests(testPackages);                                         // 18
                                                                                // 19
    this.addPackages(testPackages, 'velocity-html-reporter');                   // 20
                                                                                // 21
    // remove self so example tests aren't added back once user removes them    // 22
    // Note: this causes an error on the console:                               // 23
    //   "error: no such package: 'velocity-quick-start'"                       // 24
    // but then the app is restarted so it actually works but just looks bad.   // 25
    //this.removePackage('velocity-quick-start');                               // 26
  },  // end exec                                                               // 27
                                                                                // 28
                                                                                // 29
  addPackages: function (/* arguments */) {                                     // 30
    var requestedPackagesToAdd,                                                 // 31
        packagesToAdd = [],                                                     // 32
        smartJson;                                                              // 33
                                                                                // 34
    requestedPackagesToAdd = _.flatten(Array.prototype.slice.call(arguments));  // 35
    smartJson = this.readSmartJson();                                           // 36
                                                                                // 37
    if (!smartJson || !smartJson.packages) {                                    // 38
        throw new Error("[velocity-quick-start] smart.json file missing " +     // 39
                        "required field 'packages'.  Exiting without adding " + // 40
                        "packages.");                                           // 41
        return;                                                                 // 42
    }                                                                           // 43
                                                                                // 44
    packageMap = this.slurpPackages();                                          // 45
                                                                                // 46
    _.each(requestedPackagesToAdd, function (package) {                         // 47
      if (!packageMap[package]) {                                               // 48
        DEBUG && console.log("[velocity-quick-start] adding package '" +        // 49
                             package + "' to .meteor/packages");                // 50
        smartJson.packages[package] = {};                                       // 51
        packagesToAdd.push(package);                                            // 52
      }                                                                         // 53
    });                                                                         // 54
                                                                                // 55
    this.updateMeteorPackagesFile(packagesToAdd);                               // 56
                                                                                // 57
    // update the smart.json file                                               // 58
    this.writeSmartJson(smartJson);                                             // 59
                                                                                // 60
  },  // end addPackages                                                        // 61
                                                                                // 62
                                                                                // 63
  /**                                                                           // 64
   * Read's this app's '.meteor/packages' file and parses out all               // 65
   * the packages.  Returns a hashmap where each package is a key.              // 66
   *                                                                            // 67
   * @method slurpPackages                                                      // 68
   * @return {Object} key/value pairs; key = package name, value = true         // 69
   */                                                                           // 70
  slurpPackages: function () {                                                  // 71
    var contents,                                                               // 72
        packageMap = {};                                                        // 73
                                                                                // 74
    try {                                                                       // 75
      contents = (this.readMeteorPackagesFile() || '').trim();                  // 76
    } catch (err) {                                                             // 77
      console.log("[velocity-quick-start] Error reading",                       // 78
                  path.join(pwd, '.meteor/packages'), err);                     // 79
      throw err;                                                                // 80
    }                                                                           // 81
                                                                                // 82
    if (!contents) {                                                            // 83
      throw new Error("[velocity-quick-start] Invalid state.  The '",           // 84
                      path.join(pwd, '.meteor/packages'), "file is empty. " +   // 85
                      "This is should not be possible for Meteor apps and " +   // 86
                      "indicates a problem of some kind.");                     // 87
    }                                                                           // 88
                                                                                // 89
    _.each(contents.split('\n'), function (line) {                              // 90
      if (!line || !line.trim()) return;                                        // 91
                                                                                // 92
      line = line.trim();                                                       // 93
                                                                                // 94
      // skip comments                                                          // 95
      if (line[0] === '#') return;                                              // 96
                                                                                // 97
      packageMap[line] = true;                                                  // 98
    });                                                                         // 99
                                                                                // 100
    return packageMap;                                                          // 101
  },  // end slurpPackages                                                      // 102
                                                                                // 103
                                                                                // 104
  copySampleTests: function (testPackages) {                                    // 105
    var i = testPackages.length - 1,                                            // 106
        package;                                                                // 107
                                                                                // 108
    for (; package = testPackages[i]; i--) {                                    // 109
      try {                                                                     // 110
        Meteor.call('copySampleTests', {framework: package});                   // 111
      } catch (ex) {                                                            // 112
        console.log("[velocity-quick-start] could not generate sample tests " + // 113
                    "for test framework: '" + package +                         // 114
                    "'.  Reason:", ex.message);                                 // 115
      }                                                                         // 116
    }                                                                           // 117
  },  // end copySampleTests                                                    // 118
                                                                                // 119
                                                                                // 120
  removePackage: function (packageName) {                                       // 121
    var packagePath = path.join(pwd, 'packages', packageName),                  // 122
        statInfo,                                                               // 123
        smartJson;                                                              // 124
                                                                                // 125
    DEBUG && console.log("[velocity-quick-start] removing package '" +          // 126
                packageName + "'");                                             // 127
                                                                                // 128
    // remove from .meteor/packages                                             // 129
    this.execShellCommand('mrt remove ' + packageName);                         // 130
                                                                                // 131
    // remove from 'packages' directory                                         // 132
    statInfo = fs.lstatSync(packagePath);                                       // 133
    if (statInfo.isSymbolicLink()) {                                            // 134
      // remove link                                                            // 135
      fs.unlinkSync(packagePath);                                               // 136
    } else if (statInfo.isDirectory()) {                                        // 137
      rimraf.sync(packagePath);                                                 // 138
    } else {                                                                    // 139
      console.log("[velocity-quick-start] Error removing package '" +           // 140
                  packageName + "'. Expected '" + packagePath + "' to " +       // 141
                  "reference a directory or sym-link but it does not.");        // 142
      return;                                                                   // 143
    }                                                                           // 144
                                                                                // 145
    // remove from smart.json                                                   // 146
    smartJson = this.readSmartJson();                                           // 147
    if (smartJson) {                                                            // 148
      delete smartJson.packages[packageName];                                   // 149
      this.writeSmartJson(smartJson);                                           // 150
    }                                                                           // 151
  },  // end removePackage                                                      // 152
                                                                                // 153
                                                                                // 154
  readSmartJson: function () {                                                  // 155
    try {                                                                       // 156
      var rawConfig = fs.readFileSync(path.join(pwd, 'smart.json')).toString(); // 157
      return JSON.parse(rawConfig);                                             // 158
                                                                                // 159
    } catch (err) {                                                             // 160
      console.log("[velocity-quick-start] Error reading app's " +               // 161
                  "smart.json file:", err);                                     // 162
      throw err;                                                                // 163
    }                                                                           // 164
  },  // end readSmartJson                                                      // 165
                                                                                // 166
                                                                                // 167
  readMeteorPackagesFile: function (filepath) {                                 // 168
    filepath = filepath || path.join(pwd, '.meteor/packages');                  // 169
    return fs.readFileSync(filepath).toString();                                // 170
  },                                                                            // 171
                                                                                // 172
                                                                                // 173
  writeSmartJson: function (json) {                                             // 174
    var smartJsonString,                                                        // 175
        smartJsonPath;                                                          // 176
                                                                                // 177
    if (!json) return;                                                          // 178
                                                                                // 179
    // Make a nicely formated default json string                               // 180
    smartJsonString = JSON.stringify(json, null, 2) + "\n";                     // 181
                                                                                // 182
    smartJsonPath = path.join(pwd, 'smart.json');                               // 183
                                                                                // 184
    // Write to disk                                                            // 185
    if (fs.existsSync(smartJsonPath))                                           // 186
      fs.writeFileSync(smartJsonPath, smartJsonString);                         // 187
  },  // end writeSmartJson                                                     // 188
                                                                                // 189
                                                                                // 190
  /**                                                                           // 191
   * Append new package names to the .meteor/packages file.                     // 192
   * If .meteor/packages does not exist, create it.                             // 193
   *                                                                            // 194
   * @method updateMeteorPackagesFile                                           // 195
   * @param {Array|String} newPackages List of package names to append          // 196
   */                                                                           // 197
  updateMeteorPackagesFile: function (newPackages) {                            // 198
    var filePath;                                                               // 199
                                                                                // 200
    if ('string' === typeof newPackages) {                                      // 201
      newPackages = newPackages.trim();                                         // 202
    } else if (_.isArray(newPackages)) {                                        // 203
      newPackages = newPackages.join('\n').trim();                              // 204
    } else {                                                                    // 205
      return;                                                                   // 206
    }                                                                           // 207
                                                                                // 208
    // bail if empty                                                            // 209
    if (!newPackages) return;                                                   // 210
                                                                                // 211
    filePath = path.join(pwd, '.meteor/packages');                              // 212
                                                                                // 213
    if (fs.existsSync(filePath)) {                                              // 214
      fs.appendFileSync(filePath, '\n' + newPackages);                          // 215
    } else {                                                                    // 216
      fs.writeFileSync(filePath, newPackages);                                  // 217
    }                                                                           // 218
  },  // end updateMeteorPackagesFile                                           // 219
                                                                                // 220
                                                                                // 221
  execShellCommand: function (command) {                                        // 222
    var command,                                                                // 223
        options,                                                                // 224
        child,                                                                  // 225
        timeout = false;                                                        // 226
                                                                                // 227
    options = { rollingTimeout: 5000 };                                         // 228
                                                                                // 229
    // execute child process                                                    // 230
    child = exec(command, options, function (err, stdout, stderr) {             // 231
      if (err) {                                                                // 232
        if (timeout) {                                                          // 233
          console.error(command, 'timed out');                                  // 234
        }                                                                       // 235
        console.error(err.message, err.code);                                   // 236
        console.error(stdout);                                                  // 237
        console.error(stderr);                                                  // 238
      } else {                                                                  // 239
        DEBUG && console.log(command, 'successful!');                           // 240
        DEBUG && console.log(stdout);                                           // 241
      }                                                                         // 242
    });                                                                         // 243
                                                                                // 244
    child.on('rolling-timeout', function () {                                   // 245
      timeout = true;                                                           // 246
    });                                                                         // 247
  }  // end execShellCommand                                                    // 248
                                                                                // 249
});  // end _.extend(QuickStart.prototype, {...})                               // 250
                                                                                // 251
//////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
// packages/velocity-quick-start/main.js                                        //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////
                                                                                //
"use strict";                                                                   // 1
                                                                                // 2
var quickStart = new QuickStart(),                                              // 3
    frameworks = [                                                              // 4
      'jasmine-unit',                                                           // 5
      'mocha-web-velocity',                                                     // 6
      'jasmine'                                                                 // 7
    ];                                                                          // 8
                                                                                // 9
quickStart.exec(frameworks);                                                    // 10
                                                                                // 11
//////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['velocity-quick-start'] = {};

})();

//# sourceMappingURL=velocity-quick-start.js.map
