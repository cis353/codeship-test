(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Velocity = Package.velocity.Velocity;
var VelocityTestFiles = Package.velocity.VelocityTestFiles;
var VelocityFixtureFiles = Package.velocity.VelocityFixtureFiles;
var VelocityTestReports = Package.velocity.VelocityTestReports;
var VelocityAggregateReports = Package.velocity.VelocityAggregateReports;
var VelocityLogs = Package.velocity.VelocityLogs;
var VelocityMirrors = Package.velocity.VelocityMirrors;
var _ = Package.underscore._;
var PackageStubber = Package['package-stubber'].PackageStubber;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/jasmine-unit/main.js                                                                      //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
/*jshint -W117, -W030, -W044, -W016  */                                                               // 1
/* global                                                                                             // 2
 DEBUG:true                                                                                           // 3
 */                                                                                                   // 4
                                                                                                      // 5
(function () {                                                                                        // 6
                                                                                                      // 7
  "use strict";                                                                                       // 8
                                                                                                      // 9
  var ANNOUNCE_STRING = 'Jasmine-Unit is loaded',                                                     // 10
      pwd = process.env.PWD,                                                                          // 11
      DEBUG = process.env.JASMINE_DEBUG,                                                              // 12
      spawn = Npm.require('child_process').spawn,                                                     // 13
      parseString = Npm.require('xml2js').parseString,                                                // 14
      glob = Npm.require('glob'),                                                                     // 15
      fs = Npm.require('fs'),                                                                         // 16
      path = Npm.require('path'),                                                                     // 17
      rimraf = Npm.require('rimraf'),                                                                 // 18
      testReportsPath = _p(pwd + '/tests/.reports/jasmine-unit'),                                     // 19
      args,                                                                                           // 20
      jasmineCli,                                                                                     // 21
      closeFunc,                                                                                      // 22
      rerunTests,                                                                                     // 23
      RUN_TEST_THROTTLE_TIME = 100;                                                                   // 24
                                                                                                      // 25
                                                                                                      // 26
  //////////////////////////////////////////////////////////////////////                              // 27
  // set up jasmine cli arguments                                                                     // 28
  //                                                                                                  // 29
                                                                                                      // 30
  // OS-independent path to jasmine cli                                                               // 31
  jasmineCli = _p(pwd + '/packages/jasmine-unit/.npm/package/node_modules/jasmine-node-reporter-fix/lib/jasmine-node/cli.js');
                                                                                                      // 33
                                                                                                      // 34
  args = [                                                                                            // 35
    jasmineCli,                                                                                       // 36
    '--coffee',                                                                                       // 37
    '--color',                                                                                        // 38
    '--verbose',                                                                                      // 39
    '--match',                                                                                        // 40
    '.*-jasmine-unit\.',                                                                              // 41
    '--matchall',                                                                                     // 42
    '--junitreport',                                                                                  // 43
    '--output',                                                                                       // 44
    testReportsPath,                                                                                  // 45
    _p(pwd + '/packages/jasmine-unit/lib'),                                                           // 46
    _p(pwd + '/tests')                                                                                // 47
  ];                                                                                                  // 48
                                                                                                      // 49
                                                                                                      // 50
  //////////////////////////////////////////////////////////////////////                              // 51
  // private functions                                                                                // 52
  //                                                                                                  // 53
                                                                                                      // 54
                                                                                                      // 55
                                                                                                      // 56
  /**                                                                                                 // 57
   * Reports test results back to velocity core.  Called once jasmine child                           // 58
   * process exits                                                                                    // 59
   *                                                                                                  // 60
   * @method closeFunc                                                                                // 61
   * @private                                                                                         // 62
   */                                                                                                 // 63
  closeFunc = Meteor.bindEnvironment(function () {                                                    // 64
    var newResults = [],                                                                              // 65
        globSearchString = _p('**/TEST-*.xml'),                                                       // 66
        xmlFiles = glob.sync(globSearchString, { cwd: testReportsPath });                             // 67
                                                                                                      // 68
    _.each(xmlFiles, function (xmlFile, index) {                                                      // 69
      parseString(fs.readFileSync(testReportsPath + path.sep + xmlFile), function (err, result) {     // 70
        _.each(result.testsuites.testsuite, function (testsuite) {                                    // 71
          _.each(testsuite.testcase, function (testcase) {                                            // 72
            var result = ({                                                                           // 73
              name: testcase.$.name,                                                                  // 74
              framework: 'jasmine-unit',                                                              // 75
              result: testcase.failure ? 'failed' : 'passed',                                         // 76
              timestamp: testsuite.$.timestamp,                                                       // 77
              time: testcase.$.time,                                                                  // 78
              ancestors: [testcase.$.classname]                                                       // 79
            });                                                                                       // 80
                                                                                                      // 81
            if (testcase.failure) {                                                                   // 82
              _.each(testcase.failure, function (failure) {                                           // 83
                result.failureType = failure.$.type;                                                  // 84
                result.failureMessage = failure.$.message;                                            // 85
                result.failureStackTrace = failure._;                                                 // 86
              });                                                                                     // 87
            }                                                                                         // 88
            result.id = 'jasmine-unit:' + hashCode(xmlFile + testcase.$.classname + testcase.$.name); // 89
            newResults.push(result.id);                                                               // 90
            Meteor.call('postResult', result);                                                        // 91
          });                                                                                         // 92
        });                                                                                           // 93
      });                                                                                             // 94
                                                                                                      // 95
      if (index === xmlFiles.length - 1) {                                                            // 96
        Meteor.call('resetReports', {framework: 'jasmine-unit', notIn: newResults});                  // 97
        Meteor.call('completed', {framework: 'jasmine-unit'});                                        // 98
      }                                                                                               // 99
    });                                                                                               // 100
  });  // end closeFunc                                                                               // 101
                                                                                                      // 102
                                                                                                      // 103
  /**                                                                                                 // 104
   * Runs tests and logs results to velocity core.                                                    // 105
   *                                                                                                  // 106
   * @method rerunTests                                                                               // 107
   * @private                                                                                         // 108
   */                                                                                                 // 109
  function _rerunTests () {                                                                           // 110
    Meteor.call('resetLogs', {framework: 'jasmine-unit'});                                            // 111
    rimraf.sync(testReportsPath);                                                                     // 112
                                                                                                      // 113
    PackageStubber.stubPackages();                                                                    // 114
                                                                                                      // 115
    DEBUG && console.log('jasmine cli: ', process.execPath, args.join(' '));                          // 116
                                                                                                      // 117
    var jasmineNode = spawn(process.execPath, args);                                                  // 118
    jasmineNode.stdout.pipe(process.stdout);                                                          // 119
    jasmineNode.stderr.pipe(process.stderr);                                                          // 120
    jasmineNode.on('close', closeFunc);                                                               // 121
  }  // end closeFunc                                                                                 // 122
                                                                                                      // 123
                                                                                                      // 124
  /**                                                                                                 // 125
   * Lets us write paths unix-style but still be                                                      // 126
   * cross-platform compatible                                                                        // 127
   *                                                                                                  // 128
   * @method _p                                                                                       // 129
   * @param {String} unixPath path with unix-style separators                                         // 130
   * @return {String} path with platform-appropriate separator                                        // 131
   * @private                                                                                         // 132
   */                                                                                                 // 133
  function _p (unixPath) {                                                                            // 134
    return unixPath.replace('\/', path.sep);                                                          // 135
  }                                                                                                   // 136
                                                                                                      // 137
                                                                                                      // 138
  function hashCode (s) {                                                                             // 139
    return s.split("").reduce(function (a, b) {                                                       // 140
      a = ((a << 5) - a) + b.charCodeAt(0);                                                           // 141
      return a & a;                                                                                   // 142
    }, 0);                                                                                            // 143
  }                                                                                                   // 144
                                                                                                      // 145
                                                                                                      // 146
  /**                                                                                                 // 147
   * Implementation of underscore's `throttle` function which uses                                    // 148
   * Meteor.setTimeout instead of the regular one.                                                    // 149
   *                                                                                                  // 150
   * @method _throttle                                                                                // 151
   * @private                                                                                         // 152
   */                                                                                                 // 153
  function _throttle (func, wait, options) {                                                          // 154
    var context, args, result;                                                                        // 155
    var timeout = null;                                                                               // 156
    var previous = 0;                                                                                 // 157
    var _now = Date.now || function () { return new Date().getTime(); };                              // 158
    options || (options = {});                                                                        // 159
    var later = function () {                                                                         // 160
      previous = options.leading === false ? 0 : _now();                                              // 161
      timeout = null;                                                                                 // 162
      result = func.apply(context, args);                                                             // 163
      context = args = null;                                                                          // 164
    };                                                                                                // 165
    return function () {                                                                              // 166
      var now = _now();                                                                               // 167
      if (!previous && options.leading === false) {                                                   // 168
        previous = now;                                                                               // 169
      }                                                                                               // 170
      var remaining = wait - (now - previous);                                                        // 171
      context = this;                                                                                 // 172
      args = arguments;                                                                               // 173
      if (remaining <= 0) {                                                                           // 174
        Meteor.clearTimeout(timeout);                                                                 // 175
        timeout = null;                                                                               // 176
        previous = now;                                                                               // 177
        result = func.apply(context, args);                                                           // 178
        context = args = null;                                                                        // 179
      } else if (!timeout && options.trailing !== false) {                                            // 180
        timeout = Meteor.setTimeout(later, remaining);                                                // 181
      }                                                                                               // 182
      return result;                                                                                  // 183
    };                                                                                                // 184
  }  // end _throttle                                                                                 // 185
                                                                                                      // 186
                                                                                                      // 187
  // Help prevent unnecessary duplicate test runs by giving velocity core                             // 188
  // some time to notify changes before re-running tests.                                             // 189
  // We don't need the actual file names since jasmine will just execute                              // 190
  // all the matching test files each time it's run.                                                  // 191
  rerunTests = _throttle(_rerunTests, RUN_TEST_THROTTLE_TIME, {leading: false});                      // 192
                                                                                                      // 193
                                                                                                      // 194
//////////////////////////////////////////////////////////////////////                                // 195
// Register the observe that will kick things off                                                     // 196
//                                                                                                    // 197
                                                                                                      // 198
  // TODO: How can we abstract this server-side so the test frameworks                                // 199
  // don't need to know about velocity collections                                                    // 200
  VelocityTestFiles.find({targetFramework: 'jasmine-unit'}).observe({                                 // 201
    added: rerunTests,                                                                                // 202
    changed: rerunTests,                                                                              // 203
    removed: rerunTests                                                                               // 204
  });                                                                                                 // 205
                                                                                                      // 206
  console.log(ANNOUNCE_STRING);                                                                       // 207
                                                                                                      // 208
})();                                                                                                 // 209
                                                                                                      // 210
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['jasmine-unit'] = {};

})();

//# sourceMappingURL=jasmine-unit.js.map
