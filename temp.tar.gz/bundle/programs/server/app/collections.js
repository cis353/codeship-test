(function(){Posts = new Meteor.Collection('posts');

})();
